#pragma once
#include "stdafx.h"
#include <vector>
#include <QMutex>
#include "points.h"

using namespace std;

extern float  * g_pBufferStart;
extern QMutex g_pBufferStartMutex;
extern ColorSpacePoint         depth2rgb[512*424];             // Maps depth pixels to rgb pixels
extern CameraSpacePoint        depth2xyz[512*424];			 // Maps depth pixels to 3d coordinates
extern unsigned char rgbimage[1920*1080*4];
//extern VECTORRGB g_vectorRGB;
class capture 
{
public:	
	static const int        cDepthWidth = 512;
	static const int        cDepthHeight = 424;
	static const int        cColorWidth = 1920;  
	static const int        cColorHeight = 1080; 

	capture ();
	~capture ();

	void                    Update_depth();
	HRESULT                 InitializeDefaultSensor();
	RGBQUAD*			    m_depthPicturBye;
	RGBQUAD*			    m_colorPicturBye;
	bool                    mark_depth;

	USHORT                  m_maxDistance;
	USHORT                  m_minDistance;

private:
	IMultiSourceFrameReader*  m_reader; 
	ICoordinateMapper*        m_mapper; 
	IKinectSensor*            m_pKinectSensor;

	RGBQUAD*                m_pDepthRGBX;
	RGBQUAD*                m_pColorRGBX;
	void                    ProcessColor_depth(const UINT16* pBuffer_depth, int nWidth_depth, int nHeight_depth, USHORT nMinDepth, USHORT nMaxDepth,RGBQUAD *pBuffer_color);
};

