#include "glViewer.h"
using namespace std;

//VECTORRGB g_vectorRGB;

Viewer::Viewer()
{

}
void Viewer::init()
{
	// Restore previous viewer stat e.
	restoreStateFromFile();
	//setSceneRadius(100.0);
	toggleAxisIsDrawn();
	//toggleGridIsDrawn ();
	//toggleCameraIsEdited ();
	// Opens help window
	//help();
}

void Viewer::draw()
{	
	
	glDisable(GL_LIGHT0);	
	glBegin(GL_POINTS);
	for (int i=0;i<m_Vpoints.size();i++)
	{
		glVertex3f(m_Vpoints[i].x,m_Vpoints[i].y,m_Vpoints[i].z);
		glColor3f(m_RGB[i].r, m_RGB[i].g,m_RGB[i].b);
	}
	glEnd();
}

void Viewer::OnUpdate(const VECTORPOINTS  &data,const VECTORRGB &cdata)
{
	m_Vpoints=data;	
	m_RGB=cdata;
	updateGL();
}


