
#include "qt_slam.h"
#include <QtConcurrent/QtConcurrent>
#include <QLayout> 
#include <windows.h>

const int depthWidth=512;
const int depthHeight=424;
float* g_pBufferStart = NULL;
QMutex g_pBufferStartMutex;

ColorSpacePoint         depth2rgb[512*424];  
CameraSpacePoint        depth2xyz[512*424];	
unsigned char       rgbimage[1920*1080*4];

qt_slam::qt_slam(QWidget *parent)
	: QMainWindow(parent)
{
	m_isrun = true;
	m_ispoint=false;	
	m_isrun22 = false;
	ui.setupUi(this);
	m_capture.InitializeDefaultSensor();
	vewers=new Viewer();
	ui.Hlayout->addWidget(vewers);	
	connect(this, SIGNAL(depth_pictureChanged(RGBQUAD*,RGBQUAD*)), this, SLOT(depth_show_picture(RGBQUAD*,RGBQUAD*)));
	qRegisterMetaType<VECTORPOINTS>("VECTORPOINTS");
	qRegisterMetaType<VECTORRGB>("VECTORRGB");
	connect(this,SIGNAL(Points_signals(const VECTORPOINTS &,const VECTORRGB &)),vewers,SLOT( OnUpdate(const VECTORPOINTS &,const VECTORRGB &)));

}

qt_slam::~qt_slam() 
{

}
// void qt_slam::get_points()
// {
// 	m_ispoint=true;	
// 	UINT16* tmp = new UINT16[depthWidth * depthHeight];
// 	while (m_isrun)
// 	{	
// 		UINT16* pp = tmp;
// 		g_pBufferStartMutex.lock();		
// 		memcpy(tmp, g_pBufferStart, sizeof(UINT16)*depthWidth * depthHeight);
// 		g_pBufferStartMutex.unlock();		
// 
// 		if (m_capture.mark_depth == true)
// 		{
// 			VECTORPOINTS v_point;		
// 			for (float yy=0;yy<depthHeight;yy++)
// 			{
// 				for (float xx=0;xx<depthWidth;xx++)
// 				{				
// 					USHORT depth=*pp;
// 
// 					if ((depth >= m_capture.m_minDistance) && (depth <= m_capture.m_maxDistance))
// 					{
// 						Points  point={xx,yy,depth/10};
// 						v_point.push_back(point);
// 						++pp;
// 						continue;
// 					}				
// 					Points  point={xx,yy,0};
// 					v_point.push_back(point);
// 					++pp;
// 				}		
// 			}
// 			emit Points_signals(v_point);
// 		}
// 	}
// 	m_ispoint=false;
// 
// }
void qt_slam::get_points()
{
	m_ispoint=true;	
	while (m_isrun)
	{	
		if (m_capture.mark_depth == true)
		{
			VECTORRGB  v_RGB;
			for (int i=0;i<512*424;i++)
			{
				ColorSpacePoint p = depth2rgb[i];
				RGB  tem_RGB;

				if (p.X < 0 || p.Y < 0 || p.X > 1920 || p.Y > 1080) 
				{
					tem_RGB.r=0;
					tem_RGB.g=0;
					tem_RGB.b=0;
				}
				else
				{
					int idx = (int)p.X + 1920*(int)p.Y;
					tem_RGB.r = rgbimage[4*idx + 0]/255.;
					tem_RGB.g = rgbimage[4*idx + 1]/255.;
					tem_RGB.b = rgbimage[4*idx + 2]/255.;
				}
				v_RGB.push_back(tem_RGB);
			}

			VECTORPOINTS v_point;
			
			int aa=0;
			for (float yy=0;yy<depthHeight;yy++)
			{
				for (float xx=0;xx<depthWidth;xx++)
				{	
					if (depth2xyz[aa].X<(-999999999)||depth2xyz[aa].Y<(-999999999)||depth2xyz[aa].Z<(-999999999))
					{
						Points tem_point;
						tem_point.x=depth2xyz[aa].X;
						tem_point.y=depth2xyz[aa].Y;
						tem_point.z=depth2xyz[aa].Z;
						v_point.push_back(tem_point);
						aa++;
						continue;
					}
					else
					{
						Points tem_point;
						tem_point.x=depth2xyz[aa].X;
						tem_point.y=depth2xyz[aa].Y;
						tem_point.z=depth2xyz[aa].Z;
						v_point.push_back(tem_point);
						aa++;	
					}				
				}		
			}
			emit Points_signals(v_point,v_RGB);
		}
	}
	m_ispoint=false;

}

void qt_slam::get_depth_picture()
{
	m_isrun22 = true;
	while (m_isrun){
		m_capture.Update_depth();
		if (m_capture.mark_depth == true)
		{
			emit depth_pictureChanged(m_capture.m_depthPicturBye,m_capture.m_colorPicturBye);
			m_capture.mark_depth = false;
		}
	}
	m_isrun22 = false;
}

void  qt_slam::depth_show_picture(RGBQUAD* picture,RGBQUAD* cpicture)
{
	QImage qImage(reinterpret_cast<BYTE*>(picture), depthWidth, depthHeight, depthWidth * 4, QImage::Format_ARGB32_Premultiplied);
	ui.label->setPixmap(QPixmap::fromImage(qImage));
	QImage cqImage(reinterpret_cast<BYTE*>(cpicture), m_capture.cColorWidth, m_capture.cColorHeight, m_capture.cColorWidth * 4, QImage::Format_RGBA8888);
	ui.label_2->setPixmap(QPixmap::fromImage(cqImage));

}
void qt_slam::work()
{
	g_pBufferStart = new float[depthWidth * depthHeight*3];

	QtConcurrent::run(this, &qt_slam::get_depth_picture);
	QtConcurrent::run(this, &qt_slam::get_points);
} 
void qt_slam::closeEvent(QCloseEvent *event)
{
	m_isrun=false;
	while (m_isrun22||m_ispoint)
	{

	}
}