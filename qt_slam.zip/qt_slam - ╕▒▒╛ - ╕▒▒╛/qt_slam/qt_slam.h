#ifndef QT_SLAM_H
#define QT_SLAM_H

#include <QtWidgets/QMainWindow>
#include "ui_qt_slam.h"
#include"capture.h"
#include"glViewer.h"
#include "points.h"


class qt_slam : public QMainWindow
{
	Q_OBJECT

public:
	qt_slam(QWidget *parent = 0);
	~qt_slam();
	void             work();
signals:
	void  depth_pictureChanged(RGBQUAD*,RGBQUAD*);
	void  Points_signals(const VECTORPOINTS &data,const VECTORRGB &cdata);
public slots:
	void  depth_show_picture(RGBQUAD* picture,RGBQUAD* cpicture);
	//void  onTimerOut();
protected:
	void closeEvent(QCloseEvent *event);

private:
	Ui::qt_slamClass ui;
	capture			 m_capture;
	bool			 m_isrun;
	bool			 m_isrun22;
	void             get_depth_picture();
    
	Viewer           *vewers;
	bool             m_ispoint;
	void             get_points();
	//points           m_points;
};

#endif // QT_SLAM_H
