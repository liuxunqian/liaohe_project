#include <QGLViewer/qglviewer.h>
#include <vector>
#include "points.h"


class Viewer : public QGLViewer
{
	Q_OBJECT
public:
	Viewer();
public slots:
	void OnUpdate(const VECTORPOINTS  &data,const VECTORRGB &cdata);
protected :
	virtual void init();
	virtual void draw();
public:
	VECTORPOINTS     m_Vpoints;
	VECTORRGB        m_RGB;
};


