#include"capture.h"
// #include "opencv/cv.h"
// #include "opencv/highgui.h"

capture::capture():
m_pKinectSensor(NULL),
m_reader(NULL),
m_mapper(NULL),
m_pDepthRGBX(NULL),
mark_depth(false),
m_maxDistance(0),
m_minDistance(0)
{
	m_pDepthRGBX = new RGBQUAD[cDepthWidth * cDepthHeight];
    m_pColorRGBX = new RGBQUAD[cColorWidth * cColorHeight];
}

capture ::~capture()
{
	if (m_pDepthRGBX)
	{
		delete[] m_pDepthRGBX;
		m_pDepthRGBX = NULL;
	}
	

	// done with color frame reader

	SafeRelease(m_reader);

	// close the Kinect Sensor
	if (m_pKinectSensor)
	{
		m_pKinectSensor->Close();
	}

	SafeRelease(m_pKinectSensor);
}

HRESULT capture::InitializeDefaultSensor()
{

	HRESULT hr_depth;
	hr_depth = GetDefaultKinectSensor(&m_pKinectSensor);
	if (FAILED(hr_depth))
	{
		return hr_depth;
	}

	if (m_pKinectSensor)
	{
		m_pKinectSensor->get_CoordinateMapper(&m_mapper);
		hr_depth = m_pKinectSensor->Open();

		if (SUCCEEDED(hr_depth))
		{	
			hr_depth=m_pKinectSensor->OpenMultiSourceFrameReader(
				FrameSourceTypes::FrameSourceTypes_Depth| FrameSourceTypes::FrameSourceTypes_Color ,&m_reader);
		}
	}
	if ( !m_pKinectSensor||FAILED(hr_depth))
	{			
		return E_FAIL;

	}	
	return hr_depth;
}
void  capture::Update_depth()
{
	if (!(m_reader))
	{
		return;
	}

	IMultiSourceFrame* pMultiSourceFrame = NULL;  
	IDepthFrame* pDepthFrame = NULL;  
	IColorFrame* pColorFrame = NULL;

	 HRESULT hr = m_reader->AcquireLatestFrame(&pMultiSourceFrame);  
	 //�����Ϣ  
	 if (SUCCEEDED(hr))
	 {  
		 IDepthFrameReference* pDepthFrameReference = NULL;  
		 hr = pMultiSourceFrame->get_DepthFrameReference(&pDepthFrameReference);  
		 if (SUCCEEDED(hr))  
		 {  
			 hr = pDepthFrameReference->AcquireFrame(&pDepthFrame);  
		 }  
		 SafeRelease(pDepthFrameReference);  
	 }  
	 //��ɫ��Ϣ 
	 if (SUCCEEDED(hr)) 
	 {  
		 IColorFrameReference* pColorFrameReference = NULL;  
		 hr = pMultiSourceFrame->get_ColorFrameReference(&pColorFrameReference);  
		 if (SUCCEEDED(hr))  
		 {  
			 hr = pColorFrameReference->AcquireFrame(&pColorFrame);  
		 }  
		 SafeRelease(pColorFrameReference);  
	 }  

	 if (SUCCEEDED(hr))  
	 {  
		 //��ȱ���
		 IFrameDescription* pFrameDescription_depth = NULL;
		 int nWidth_depth = 0;
		 int nHeight_depth = 0;
		 USHORT nDepthMinReliableDistance = 0;
		 USHORT nDepthMaxDistance = 0;
		 UINT nBufferSize_depth = 0;
		 UINT16 *pBuffer_depth = NULL;

		 //��ɫͼ����
		 IFrameDescription* pColorFrameDescription = NULL;  
		 int nColorWidth = 0;  
		 int nColorHeight = 0;  
		 ColorImageFormat imageFormat = ColorImageFormat_None;  
		 UINT nColorBufferSize = 0;  
		 RGBQUAD *pColorBuffer = NULL;  

		 //��ȡ���ͼ����
		 if (SUCCEEDED(hr))
		 {
			 hr = pDepthFrame->get_FrameDescription(&pFrameDescription_depth);
		 }

		 if (SUCCEEDED(hr))
		 {

			 hr = pFrameDescription_depth->get_Width(&nWidth_depth);
		 }

		 if (SUCCEEDED(hr))
		 {

			 hr = pFrameDescription_depth->get_Height(&nHeight_depth);
		 }

		 if (SUCCEEDED(hr))
		 {
			 hr = pDepthFrame->get_DepthMinReliableDistance(&nDepthMinReliableDistance);
			 m_minDistance=nDepthMinReliableDistance;
		 }
		 if (SUCCEEDED(hr))
		 {
			 hr = pDepthFrame->get_DepthMaxReliableDistance(&nDepthMaxDistance);
			 m_maxDistance=nDepthMaxDistance;
		 }
		 if (SUCCEEDED(hr))
		 {
			 hr = pDepthFrame->AccessUnderlyingBuffer(&nBufferSize_depth, &pBuffer_depth);
		 }
		 //��ȡ������ͼ����													
		 
		 //��ȡ��ɫͼ����

		 if (SUCCEEDED(hr))  
		 {  
			 hr = pColorFrame->get_FrameDescription(&pColorFrameDescription);  
		 }  

		 if (SUCCEEDED(hr))  
		 {  
			 hr = pColorFrameDescription->get_Width(&nColorWidth);  
		 }  

		 if (SUCCEEDED(hr))  
		 {  
			 hr = pColorFrameDescription->get_Height(&nColorHeight);  
		 }  

		 if (SUCCEEDED(hr))  
		 {  
			 hr = pColorFrame->get_RawColorImageFormat(&imageFormat);  
		 }  

		 if (SUCCEEDED(hr))  
		 {  
			 if (imageFormat == ColorImageFormat_Bgra)  
			 {  
				 hr = pColorFrame->AccessRawUnderlyingBuffer(&nColorBufferSize, reinterpret_cast<BYTE**>(&pColorBuffer));  
			 }  
			 else if (m_pColorRGBX)  
			 {  
				 pColorBuffer = m_pColorRGBX;  
				 nColorBufferSize = cColorWidth * cColorHeight * sizeof(RGBQUAD);  
				 hr = pColorFrame->CopyConvertedFrameDataToArray(nColorBufferSize, reinterpret_cast<BYTE*>(pColorBuffer), ColorImageFormat_Rgba);  
			 }  
			 else  
			 {  
				 hr = E_FAIL;  
			 }  
		 }
		 if (SUCCEEDED(hr))
		 {
			 g_pBufferStartMutex.lock();
			 hr=m_mapper->MapDepthFrameToCameraSpace(nWidth_depth*nHeight_depth, pBuffer_depth, nWidth_depth*nHeight_depth, depth2xyz);
			 hr=m_mapper->MapDepthFrameToColorSpace(nWidth_depth*nHeight_depth,  pBuffer_depth, nWidth_depth*nHeight_depth, depth2rgb);						
			  hr=pColorFrame->CopyConvertedFrameDataToArray(cColorWidth*cColorHeight*4, rgbimage, ColorImageFormat_Rgba);
			 g_pBufferStartMutex.unlock();
		 }
		 					
		 //��ȡ��ɫͼ�������
		 if (SUCCEEDED(hr))
		 {
			 ProcessColor_depth(pBuffer_depth, nWidth_depth, nHeight_depth, nDepthMinReliableDistance, nDepthMaxDistance,pColorBuffer);
		 }
		 SafeRelease(pFrameDescription_depth);
		 SafeRelease(pColorFrameDescription);

	 }
	SafeRelease(pDepthFrame);
	SafeRelease(pColorFrame);

}

void  capture::ProcessColor_depth(const UINT16* pBuffer_depth, int nWidth_depth, int nHeight_depth, USHORT nMinDepth, USHORT nMaxDepth,RGBQUAD *pBuffer_color)
{
	
	if (m_pDepthRGBX && pBuffer_depth && (nWidth_depth == cDepthWidth) && (nHeight_depth == cDepthHeight))
	{
		RGBQUAD* pRGBX = m_pDepthRGBX;

		// end pixel is start + width*height - 1
		const UINT16* pBufferEnd = pBuffer_depth + (nWidth_depth * nHeight_depth);

		//
// 		g_pBufferStartMutex.lock();		
// 		memcpy(g_pBufferStart, pBuffer_depth, sizeof(UINT16)*nWidth_depth * nHeight_depth);
// 		g_pBufferStartMutex.unlock();		
		//static int aa = 0;
		while (pBuffer_depth < pBufferEnd)
		{
			//aa++;
			USHORT depth = *pBuffer_depth;
			//depth_vector.push_back(depth);		
			// To convert to a byte, we're discarding the most-significant
			// rather than least-significant bits.
			// We're preserving detail, although the intensity will "wrap."
			// Values outside the reliable depth range are mapped to 0 (black).

			// Note: Using conditionals in this loop could degrade performance.
			// Consider using a lookup table instead when writing production code.
			//////////////////////////////////////////////////////////////////////////liu
			BYTE intensity = 0;
			if ((depth >= nMinDepth) && (depth <= nMaxDepth))
			{
				depth = nMaxDepth - depth;
				double tem_value = (double)depth / (double)nMaxDepth;
				tem_value = tem_value * 255;
				USHORT color = (USHORT)tem_value;
				intensity = static_cast<BYTE>(color);
			}
			//////////////////////////////////////////////////////////////////////////liu
			//BYTE intensity = static_cast<BYTE>((depth >= nMinDepth) && (depth <= nMaxDepth) ? (depth % 256) : 0);	
			pRGBX->rgbRed = intensity;
			pRGBX->rgbGreen = intensity;
			pRGBX->rgbBlue = intensity;

			++pRGBX;
			++pBuffer_depth;
		}		
		m_depthPicturBye = m_pDepthRGBX;
		m_colorPicturBye = pBuffer_color;
		mark_depth = true;
		//Sleep(1000);
		//depth_vector.clear();
	}
}