#pragma once
#include <vector>
using namespace std;
struct Points
{
	float x,y,z;
};
struct RGB
{
	float r,g,b;
};
typedef vector<Points> VECTORPOINTS;
typedef vector<RGB>    VECTORRGB;