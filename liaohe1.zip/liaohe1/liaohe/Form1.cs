﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using orcl;
using world;
using Maticsoft.DBUtility;
using System.Data.OracleClient;
using System.Threading;

namespace liaohe
{
    public partial class Form1 : Form
    {
       
        private orcl1 orcl_L = new orcl1();
        private world1 world_L = new world1();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<string> time_L = orcl_L.GetTimeFormOrcl();
            for (int i = 0; i < time_L.Count;i++ )
            {
                comboBox2.Items.Add(time_L[i]);
                comboBox5.Items.Add(time_L[i]);
                comboBox4.Items.Add(time_L[i]);
            }
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            orcl1.time=comboBox2.SelectedItem.ToString();

            if (comboBox3.SelectedItem.ToString()=="面积")
            {
               if (comboBox1.SelectedItem.ToString()=="辽河保护区地表覆盖类型统计表")
               {
                   world_L.WriteToWord_dbfg_mj(orcl1.time);
               }
               if (comboBox1.SelectedItem.ToString() == "铁岭市地表覆盖类型统计表")
               {
                   world_L.WriteToWord_dbfg_tl_mj(orcl1.time);
               }
               if (comboBox1.SelectedItem.ToString() == "沈阳市地表覆盖类型统计表")
               {
                   world_L.WriteToWord_dbfg_sy_mj(orcl1.time);
               }
               if (comboBox1.SelectedItem.ToString() == "鞍山市地表覆盖类型统计表")
               {
                   world_L.WriteToWord_dbfg_as_mj(orcl1.time);
               }
               if (comboBox1.SelectedItem.ToString() == "盘锦市地表覆盖类型统计表")
               {
                   world_L.WriteToWord_dbfg_pj_mj(orcl1.time);
               }
            }
            if (comboBox3.SelectedItem.ToString() == "图斑数")
            {
                if (comboBox1.SelectedItem.ToString() == "辽河保护区地表覆盖类型统计表")
                {
                    world_L.WriteToWord_dbfg_sl(orcl1.time);
                }
                if (comboBox1.SelectedItem.ToString() == "铁岭市地表覆盖类型统计表")
                {
                    world_L.WriteToWord_dbfg_tl_sl(orcl1.time);
                }
                if (comboBox1.SelectedItem.ToString() == "沈阳市地表覆盖类型统计表")
                {
                    world_L.WriteToWord_dbfg_sy_sl(orcl1.time);
                }
                if (comboBox1.SelectedItem.ToString() == "鞍山市地表覆盖类型统计表")
                {
                    world_L.WriteToWord_dbfg_as_sl(orcl1.time);
                }
                if (comboBox1.SelectedItem.ToString() == "盘锦市地表覆盖类型统计表")
                {
                    world_L.WriteToWord_dbfg_pj_sl(orcl1.time);
                }
            }
           

         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            orcl1.time = comboBox5.SelectedItem.ToString();
            if (comboBox6.SelectedItem.ToString() == "辽河保护区道路要素统计表")
                {
                    world_L.WriteToWord_gqys_dl(orcl1.time);
                }
            if (comboBox6.SelectedItem.ToString() == "辽河保护区构筑物要素统计表")
                {
                    world_L.WriteToWord_gqys_gzw(orcl1.time);
                }
            if (comboBox6.SelectedItem.ToString() == "辽河保护区水域要素统计表")
                {
                    world_L.WriteToWord_gqys_sy(orcl1.time);
                }
            if (comboBox6.SelectedItem.ToString() == "辽河保护区地理单元要素统计表")
                {
                    world_L.WriteToWord_gqys_dldy(orcl1.time);
                }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            orcl1.time = comboBox4.SelectedItem.ToString();

            if (comboBox7.SelectedItem.ToString() == "辽河保护区管理围栏要素统计表"||comboBox7.SelectedItem.ToString() =="辽河保护区管理路要素统计表")
            {
                if (comboBox7.SelectedItem.ToString() == "辽河保护区管理围栏要素统计表")
                {
                    orcl1.yaosu = "围栏";
                }
                if (comboBox7.SelectedItem.ToString() == "辽河保护区管理路要素统计表")
                {
                    orcl1.yaosu = "管理路";
                }
                world_L.WriteToWord_ztfx_wl_gll();
            }
            if (comboBox7.SelectedItem.ToString() == "辽河保护区采砂场要素统计表")
            {
                orcl1.yaosu = "采砂场";
                
                world_L.WriteToWord_ztfx_csc();
            }
            if (comboBox7.SelectedItem.ToString() == "辽河保护区护堤林要素统计表")
            {
                orcl1.yaosu = "护堤林";
                world_L.WriteToWord_ztfx_hdl();
            }
 
            if (comboBox7.SelectedItem.ToString() == "辽河保护区植被覆盖程度指数统计表")
            {
                //orcl1.yaosu = "护堤林";
                world_L.WriteToWord_ztfx_zbfg();
            }
            if (comboBox7.SelectedItem.ToString() == "辽河保护区水体覆盖程度指数统计表")
            {
                //orcl1.yaosu = "护堤林";
                world_L.WriteToWord_ztfx_stfz();
            }
            if (comboBox7.SelectedItem.ToString() == "辽河保护区交通网络密度统计表")
            {
                //orcl1.yaosu = "护堤林";
                world_L.WriteToWord_ztfx_jtwlmd();
            }

        }
        //结果统计部分
        public static string conn = DbHelperOra.connectionString;
        public static string cityTableName = "BOUA5_O";
        public static string sourceTableName = "LCA_";
        public static string[] tableNameCC = { "0100", "0200", "0300", "0400", "0500", "0600", "0700", "0800", "0900", "1000" };
        public static string[] tableName = { "GENGDI", "YUANDI", "LINDI", "CAODI", "FANGWUJIANZHU", "DAOLU", "GOUZHUWU", "DUIJUEDI", "HUANGMO", "SHUIYU" };
        public static string[] areaTableName = { "BUCP_", "FHLA_", "SFCA_", "SFCP_" };
        public static string[] lengthTableName = { "HYDL_", "LCTL_", "LGLL_", "LRDL_", "LRRL_", "LVLL_", "SFCL_" };
        public static string year;
        //获得年份
        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            year = this.comboBox8.Text;
        }
        private void comboBox8_MouseClick(object sender, MouseEventArgs e)
        {
            comboBox8.Items.Clear();
            string select = "select timesid from lh_times";
            OracleDataReader dr = DbHelperOra.ExecuteReader(select);
            while (dr.Read())
            {
                comboBox8.Items.Add(dr["timesid"]);
            }
            dr.Close();
        }
        //日志信息
        public delegate void SetTextCallback(string text);
        //在给textBox1.text赋值的地方调用以下方法即可
        private void SetText(string text)
        {
            // InvokeRequired需要比较调用线程ID和创建线程ID
            // 如果它们不相同则返回true
            if (this.textBox1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.textBox1.AppendText(text);
                this.textBox1.ScrollToCaret();
            }
        }
        //地表覆盖统计area
        public delegate void BarDelegateDQ();
        private void UpdateBarDQ()
        {
            progressBar1.Value++;
            if (progressBar1.Value == progressBar1.Maximum)
            {
                MessageBox.Show("地表覆盖AREA数据建立完成！");
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            progressBar1.Minimum = 0;
            progressBar1.Maximum = tableNameCC.Length;
            int sWidth = 1;
            bool ThreadPoolReDBFG = ThreadPool.QueueUserWorkItem(new WaitCallback(briefThreadQueryDBFG), sWidth);
            if (!ThreadPoolReDBFG)
            {
                MessageBox.Show("地表覆盖数据建立失败！");
            }
        }
        private void briefThreadQueryDBFG(Object sWidth)
        {
            for (int i = 0; i < tableNameCC.Length; i++)
            {
                try
                {
                    string sSql = "select count(*) from user_tables where TABLE_NAME = '" + tableName[i] + "_A'";
                    bool errorNum = DbHelperOra.Exists(sSql);
                    if (errorNum == false)
                    {
                        sSql = "create table " + tableName[i] + "_A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),timesid number(4),area number(38))";
                        DbHelperOra.ExecuteSql(sSql);
                        SetText(tableName[i] + "_A  表已创建完毕！\r\n");
                    }
                    else
                    {
                        SetText(tableName[i] + "_A  表已存在！\r\n");
                    }
                    DataSet contentDs;
                    sSql = "select p.objectid,a.objectid,a.name,st_area(st_intersection(p.shape,a.shape)) from " + sourceTableName + year + "_O p, " + cityTableName +
                        " a where st_intersects(p.shape,a.shape) = 1 and a.objectid in (select h.objectid from " + cityTableName + " h) and" +
                        " p.objectid in (select h.objectid from " + sourceTableName + year + "_O h where h.cc = '" + tableNameCC[i] + "')";
                    contentDs = DbHelperOra.Query(sSql);
                    for (int k = 0; k < contentDs.Tables[0].Rows.Count; k++)
                    {
                        string cmdText = "insert into " + tableName[i] + "_A(objectid,cc,fid,name,timesid,area) values(" + contentDs.Tables[0].Rows[k][0] + ",'" +
                            tableNameCC[i] + "'," + contentDs.Tables[0].Rows[k][1] + ",'" + contentDs.Tables[0].Rows[k][2] + "'," + year + "," + contentDs.Tables[0].Rows[k][3] + ")";
                        DbHelperOra.ExecuteSql(cmdText);
                    }
                    contentDs.Clear();
                    sSql = "delete from " + tableName[i] + "_A t where t.area = 0";
                    DbHelperOra.ExecuteSql(sSql);
                    this.Invoke(new BarDelegateDQ(UpdateBarDQ));
                }
                catch
                {
                    SetText(tableName[i] + "_A  表生成错误！");
                }
            }
            return;
        }
        //删除地表覆盖area
        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < tableNameCC.Length; i++)
            {
                try
                {
                    string sSql = "drop table " + tableName[i] + "_A";
                    DbHelperOra.ExecuteSql(sSql);
                    SetText(tableName[i] + "_A  表已删除！\r\n");
                }
                catch
                {
                    SetText(tableName[i] + "_A  表不存在！\r\n");
                }
            }
        }
        //国情要素查询
        public delegate void BarDelegateGQ();
        private void UpdateBarGQ()
        {
            progressBar2.Value++;
            if (progressBar2.Value == progressBar2.Maximum)
            {
                MessageBox.Show("国情要素数据建立完成！");
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {
            progressBar2.Value = 0;
            progressBar2.Minimum = 0;
            progressBar2.Maximum = areaTableName.Length + lengthTableName.Length;
            int sWidth = 1;
            bool ThreadPoolRe = ThreadPool.QueueUserWorkItem(new WaitCallback(briefThreadQueryGQYS), sWidth);
            if (!ThreadPoolRe)
            {
                MessageBox.Show("国情要素数据建立失败！");
            }
        }
        private void briefThreadQueryGQYS(Object sWidth)
        {
            for (int i = 0; i < areaTableName.Length; i++)
            {
                try
                {
                    string sSql = "select count(*) from user_tables where TABLE_NAME = '" + areaTableName[i] + "A'";
                    bool errorNum = DbHelperOra.Exists(sSql);
                    if (errorNum == false)
                    {
                        sSql = "create table " + areaTableName[i] + "A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),timesid number(4),area number(38)) ";
                        DbHelperOra.ExecuteSql(sSql);
                        SetText(areaTableName[i] + "A  表已创建完毕！\r\n");
                    }
                    else
                    {
                        SetText(areaTableName[i] + "A  表已存在！\r\n");
                    }
                    DataSet contentDs;
                    sSql = "select p.objectid,p.cc,a.objectid,a.name,st_area(st_intersection(p.shape,a.shape)) from " + areaTableName[i] + year + "_O p, " + cityTableName +
                            " a where st_intersects(p.shape,a.shape) = 1 and a.objectid in (select h.objectid from " + cityTableName + " h) and" +
                            " p.objectid in (select h.objectid from " + areaTableName[i] + year + "_O h)";
                    contentDs = DbHelperOra.Query(sSql);
                    for (int j = 0; j < contentDs.Tables[0].Rows.Count; j++)
                    {
                        try
                        {
                            string cmdText = "insert into " + areaTableName[i] + "A(objectid,cc,fid,name,timesid,area) values(" + contentDs.Tables[0].Rows[j][0] + ",'"
                                    + contentDs.Tables[0].Rows[j][1] + "'," + contentDs.Tables[0].Rows[j][2] + ",'" + contentDs.Tables[0].Rows[j][3] + "',"
                                    + year + "," + contentDs.Tables[0].Rows[j][4] + ")";
                            DbHelperOra.ExecuteSql(cmdText);
                        }
                        catch
                        {
                            SetText(areaTableName[i] + year + "_O  第" + j + "条数据出现问题");
                        }
                    }
                    contentDs.Clear();

                    this.Invoke(new BarDelegateGQ(UpdateBarGQ));
                }
                catch
                {
                    SetText(areaTableName[i] + year + "_O数据出现问题");
                }
            }
            string sSqlDel = "delete from FHLA_A t where t.area = 0";
            DbHelperOra.ExecuteSql(sSqlDel);
            sSqlDel = "delete from SFCA_A t where t.area = 0";
            DbHelperOra.ExecuteSql(sSqlDel);
            for (int i = 4; i < lengthTableName.Length; i++)
            {
                try
                {
                    string sSql = "select count(*) from user_tables where TABLE_NAME = '" + lengthTableName[i] + "A'";
                    bool errorNum = DbHelperOra.Exists(sSql);
                    if (errorNum == false)
                    {
                        sSql = "create table " + lengthTableName[i] + "A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),timesid number(4),length number(38)) ";
                        DbHelperOra.ExecuteSql(sSql);
                        SetText(lengthTableName[i] + "A  表已创建完毕！\r\n");
                    }
                    else
                    {
                        SetText(lengthTableName[i] + "A  表已存在！\r\n");
                    }
                    DataSet contentDs;
                    sSql = "select p.objectid,p.cc,a.objectid,a.name,st_length(st_intersection(p.shape,a.shape)) from " + lengthTableName[i] + year + "_O p, " + cityTableName +
                            " a where st_intersects(p.shape,a.shape) = 1 and a.objectid in (select h.objectid from " + cityTableName + " h) and" +
                            " p.objectid in (select h.objectid from " + lengthTableName[i] + year + "_O h)";
                    contentDs = DbHelperOra.Query(sSql);
                    for (int j = 0; j < contentDs.Tables[0].Rows.Count; j++)
                    {
                        try
                        {
                            string cmdText = "insert into " + lengthTableName[i] + "A(objectid,cc,fid,name,timesid,length) values(" + contentDs.Tables[0].Rows[j][0] + ",'" +
                                            contentDs.Tables[0].Rows[j][1] + "'," + contentDs.Tables[0].Rows[j][2] + ",'" + contentDs.Tables[0].Rows[j][3] + "',"
                                            + year + "," + contentDs.Tables[0].Rows[j][4] + ")";
                            DbHelperOra.ExecuteSql(cmdText);
                        }
                        catch
                        {
                            SetText(lengthTableName[i] + year + "_O  第" + j + "条数据出现问题");
                        }
                    }
                    contentDs.Clear();
                    sSql = "delete from " + lengthTableName[i] + "A t where t.length = 0";
                    DbHelperOra.ExecuteSql(sSql);
                    this.Invoke(new BarDelegateGQ(UpdateBarGQ));
                }
                catch
                {
                    SetText(lengthTableName[i] + year + "_O数据出现问题");
                }
            }
            return;
        }
        //删除国情要素area
        private void button7_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < areaTableName.Length; i++)
            {
                try
                {
                    string sSql = "drop table " + areaTableName[i] + "A";
                    DbHelperOra.ExecuteSql(sSql);
                    SetText(areaTableName[i] + "A  表已删除！\r\n");
                }
                catch
                {
                    SetText(areaTableName[i] + "A  表不存在！\r\n");
                }
            }
            for (int i = 0; i < lengthTableName.Length; i++)
            {
                try
                {
                    string sSql = "drop table " + lengthTableName[i] + "A";
                    DbHelperOra.ExecuteSql(sSql);
                    SetText(lengthTableName[i] + "A  表已删除！\r\n");
                }
                catch
                {
                    SetText(lengthTableName[i] + "A  表不存在！\r\n");
                }
            }
        }
        //县与保护区相切
        private void button8_Click(object sender, EventArgs e)
        {
            string cityTableName = "BOUA5_O";
            string resTableName = "BOUA9_O";
            string tableName = resTableName.Substring(0, resTableName.Length - 2);
            string sSql = "select count(*) from user_tables where TABLE_NAME = '" + tableName + "_A'";
            bool errorNum = DbHelperOra.Exists(sSql);
            if (errorNum == false)
            {
                sSql = "create table " + tableName + "_A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),area number(38))";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已创建完毕！\r\n");
            }
            else
            {
                sSql = "drop table " + tableName + "_A";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已删除\r\n！");
                sSql = "create table " + tableName + "_A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),area number(38))";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已创建完毕！\r\n");
            }
            DataSet contentDs;
            sSql = "select p.objectid,p.cc,a.objectid,a.name,st_area(st_intersection(p.shape,a.shape)) from " + cityTableName + " p, " + resTableName +
                    " a where st_intersects(p.shape,a.shape) = 1";
            contentDs = DbHelperOra.Query(sSql);
            for (int k = 0; k < contentDs.Tables[0].Rows.Count; k++)
            {
                string cmdText = "insert into " + tableName + "_A(objectid,cc,fid,name,area) values(" + contentDs.Tables[0].Rows[k][0] + ",'" +
                        contentDs.Tables[0].Rows[k][1] + "'," + contentDs.Tables[0].Rows[k][2] + ",'" + contentDs.Tables[0].Rows[k][3] + "'," +
                contentDs.Tables[0].Rows[k][4] + ")";
                DbHelperOra.ExecuteSql(cmdText);
            }
            SetText(tableName + "_A  表已完毕！\r\n");
            return;
        }
        //市与保护区相切
        private void button9_Click(object sender, EventArgs e)
        {
            string cityTableName = "BOUA4_O";
            string resTableName = "BOUA9_O";
            string tableName = cityTableName.Substring(0, cityTableName.Length - 2);
            string sSql = "select count(*) from user_tables where TABLE_NAME = '" + tableName + "_A'";
            bool errorNum = DbHelperOra.Exists(sSql);
            if (errorNum == false)
            {
                sSql = "create table " + tableName + "_A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),area number(38))";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已创建完毕！\r\n");
            }
            else
            {
                sSql = "drop table " + tableName + "_A";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已删除！\r\n");
                sSql = "create table " + tableName + "_A (objectid integer,cc nvarchar2(8),fid integer,name nvarchar2(64),area number(38))";
                DbHelperOra.ExecuteSql(sSql);
                SetText(tableName + "_A  表已创建完毕！\r\n");
            }
            DataSet contentDs;
            sSql = "select p.objectid,p.cc,a.objectid,a.name,st_area(st_intersection(p.shape,a.shape)) from " + cityTableName + " p, " + resTableName +
                    " a where st_intersects(p.shape,a.shape) = 1";
            contentDs = DbHelperOra.Query(sSql);
            for (int k = 0; k < contentDs.Tables[0].Rows.Count; k++)
            {
                string cmdText = "insert into " + tableName + "_A(objectid,cc,fid,name,area) values(" + contentDs.Tables[0].Rows[k][0] + ",'" +
                        contentDs.Tables[0].Rows[k][1] + "'," + contentDs.Tables[0].Rows[k][2] + ",'" + contentDs.Tables[0].Rows[k][3] + "'," +
                contentDs.Tables[0].Rows[k][4] + ")";
                DbHelperOra.ExecuteSql(cmdText);
            }
            SetText(tableName + "_A  表已完毕！\r\n");
            return;
        }

        
        


    }
}
