﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using orcl;
namespace world
{
    public class world1
    {
        private orcl1 orcl_W =new orcl1();

        private _Application app = new Microsoft.Office.Interop.Word.Application();
        private _Document doc = null;
        private object unknow = Type.Missing;
        private Microsoft.Office.Interop.Word.Table newTable = null;
        private static object fileName = "F:/code/download_dll/web/web/word/xx.docx";

        //地表覆盖
        private string[] firstRow = { "行政县", "耕地(0100)", "园地(0200)", "林地(0300)", "草地(0400)", "房屋建筑(0500)", "道路(0600)", "构筑物(0700)", "人工堆掘地(0800)", "荒漠与裸露地表(0900)", "水域(1000)","总计" };
        private string[] firstColumn = { "沈北新区", "辽中县", "康平县", "法库县", "新民市", "台安县", "双台子区", "大洼县", "银州区", "铁岭县", "昌图县", "开原市", "兴隆台区", "盘山县", "总计" };
        //国情要素
        private string[] xingzhengshi = { "铁岭市", "沈阳市", "鞍山市", "盘锦市" };
        private string[] daoluItem = { "行政市", "铁路（0610）", "公路（0620）", "城市道路（0630）", "乡村道路（0640）", "数量", "长度", "总计" };       
        private string[] gouzhuwuItem = { "行政市", "堤坝（0721）", "闸（0722）", "排水泵站（0723）", "桥梁（0732）", "高速公路出入口（0735）", "加油（气）、充电站(0736)", "长度", "数量", "总计" };
        private string[] shuiyuItem = { "行政市", "河流（1011）", "水渠（1012）", "水库（1031）", "数量", "长度", "总计" };
        private string[] dilidanyuanItem = { "行政县", "风景名胜区、旅游区（1126）", "居住小区（1141）", "工矿企业（1142）", "行政村（1117）", "单位院落 （1143）" };

        //数据专题
        private string[] Column1 = { "市级行政区", "铁岭市", "沈阳市", "鞍山市", "盘锦市" };
        private string[] Column2 = { "县级行政区", "银州区", "铁岭县", "开原市", "昌图县", "沈北新区", "新民市", "辽中县", "康平县", "法库县", "台安县", "兴隆台区", "双台子区", "盘山县", "大洼县" };
        private string[] Item = { "统计量", "段数", "长度", "小计（长度）", "合计（长度）", "图斑数", "面积", "小计", "合计", "占比", "露天矿", "总计" };
        private string[] geshu_yaosu = new string[14];
        private string[] changdu_yaosu = new string[14];
        private string[] xiaojichangdu = new string[8];


        //地表覆盖
        private void OpenWordFile(object wordName)
        {
            app = new Microsoft.Office.Interop.Word.Application();
            doc = app.Documents.Open(ref wordName, ref unknow, ref unknow, ref unknow, ref unknow, ref unknow,
               ref unknow, ref unknow, ref unknow, ref unknow, ref unknow,
               ref unknow, ref unknow, ref unknow, ref unknow, ref unknow);
            app.Selection.PageSetup.Orientation = Microsoft.Office.Interop.Word.WdOrientation.wdOrientLandscape; 
            app.Visible = true;
        }
        private void CreateTable(int rows,int columns)
        {
            newTable = doc.Tables.Add(app.Selection.Range, rows, columns, ref unknow, ref unknow);
            newTable.Borders.OutsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
            newTable.Borders.InsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;    
        }

        public void WriteToWord_dbfg_mj(string time)
        {
            
            OpenWordFile(fileName);
            CreateTable(16, 12);
            for (int i = 0; i < 12;i++ )
            {
                newTable.Cell(1, i+1).Range.Text = firstRow[i];
            }
            for (int i = 0; i < 15; i++)
            {
                newTable.Cell(i + 2, 1).Range.Text = firstColumn[i];
            }

            string[,] mianji = new string[14,10];
            for (int i = 1; i <= 14;i++ )
            {
                for (int j = 1; j <= 10;j++ )
                {
                    string aa = orcl_W.liaohe_dbfg_mianji(i, time, j);
                    mianji[i - 1,j - 1] = aa;
                }
            }
            for (int i = 1; i <= 14; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i+1, j+1).Range.Text = mianji[i - 1,j - 1];
                }
            }
            double[] zonghe_mianji = new double[10];
            for (int i = 0; i < 14;i++ )
            {
                zonghe_mianji[0] += Convert.ToDouble(mianji[i, 0]);
                zonghe_mianji[1] += Convert.ToDouble(mianji[i, 1]);
                zonghe_mianji[2] += Convert.ToDouble(mianji[i, 2]);
                zonghe_mianji[3] += Convert.ToDouble(mianji[i, 3]);
                zonghe_mianji[4] += Convert.ToDouble(mianji[i, 4]);
                zonghe_mianji[5] += Convert.ToDouble(mianji[i, 5]);
                zonghe_mianji[6] += Convert.ToDouble(mianji[i, 6]);
                zonghe_mianji[7] += Convert.ToDouble(mianji[i, 7]);
                zonghe_mianji[8] += Convert.ToDouble(mianji[i, 8]);
                zonghe_mianji[9] += Convert.ToDouble(mianji[i, 9]);
              
              
            }
            for (int i = 0; i < 10;i++ )
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_mianji[i]);
            }

            double[] zonghe_mianji_celan = new double[14];
            for (int i = 0; i < 10; i++)
            {
                zonghe_mianji_celan[0] += Convert.ToDouble(mianji[0, i]);
                zonghe_mianji_celan[1] += Convert.ToDouble(mianji[1, i]);
                zonghe_mianji_celan[2] += Convert.ToDouble(mianji[2, i]);
                zonghe_mianji_celan[3] += Convert.ToDouble(mianji[3, i]);
                zonghe_mianji_celan[4] += Convert.ToDouble(mianji[4, i]);
                zonghe_mianji_celan[5] += Convert.ToDouble(mianji[5, i]);
                zonghe_mianji_celan[6] += Convert.ToDouble(mianji[6, i]);
                zonghe_mianji_celan[7] += Convert.ToDouble(mianji[7, i]);
                zonghe_mianji_celan[8] += Convert.ToDouble(mianji[8, i]);
                zonghe_mianji_celan[9] += Convert.ToDouble(mianji[9, i]);
                zonghe_mianji_celan[10] += Convert.ToDouble(mianji[10, i]);
                zonghe_mianji_celan[11] += Convert.ToDouble(mianji[11, i]);
                zonghe_mianji_celan[12] += Convert.ToDouble(mianji[12, i]);
                zonghe_mianji_celan[13] += Convert.ToDouble(mianji[13, i]);
            }
            for (int i = 0; i < 14; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_mianji_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10;i++ )
            {
                sum += zonghe_mianji[i];
            }
            newTable.Cell(16, 12).Range.Text = Convert.ToString(sum);
            return;
        }
        public void WriteToWord_dbfg_sl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(16, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            for (int i = 0; i < 15; i++)
            {
                newTable.Cell(i + 2, 1).Range.Text = firstColumn[i];
            }

            string[,] tubanshu = new string[14,10];
            for (int i = 1; i <= 14; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    tubanshu[i - 1,j - 1] = orcl_W.liaohe_dbfg_tubanshu(i, time, j);
                }
            }
            for (int i = 1; i <= 14; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 1, j + 1).Range.Text = tubanshu[i - 1,j - 1];
                }
            }

            int[] zonghe_geshu = new int[10];
            for (int i = 0; i < 14; i++)
            {
                zonghe_geshu[0] += Convert.ToInt32(tubanshu[i, 0]);
                zonghe_geshu[1] += Convert.ToInt32(tubanshu[i, 1]);
                zonghe_geshu[2] += Convert.ToInt32(tubanshu[i, 2]);
                zonghe_geshu[3] += Convert.ToInt32(tubanshu[i, 3]);
                zonghe_geshu[4] += Convert.ToInt32(tubanshu[i, 4]);
                zonghe_geshu[5] += Convert.ToInt32(tubanshu[i, 5]);
                zonghe_geshu[6] += Convert.ToInt32(tubanshu[i, 6]);
                zonghe_geshu[7] += Convert.ToInt32(tubanshu[i, 7]);
                zonghe_geshu[8] += Convert.ToInt32(tubanshu[i, 8]);
                zonghe_geshu[9] += Convert.ToInt32(tubanshu[i, 9]);


            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_geshu[i]);
            }

            int[] zonghe_geshu_celan = new int[14];
            for (int i = 0; i < 10; i++)
            {
                zonghe_geshu_celan[0] += Convert.ToInt32(tubanshu[0, i]);
                zonghe_geshu_celan[1] += Convert.ToInt32(tubanshu[1, i]);
                zonghe_geshu_celan[2] += Convert.ToInt32(tubanshu[2, i]);
                zonghe_geshu_celan[3] += Convert.ToInt32(tubanshu[3, i]);
                zonghe_geshu_celan[4] += Convert.ToInt32(tubanshu[4, i]);
                zonghe_geshu_celan[5] += Convert.ToInt32(tubanshu[5, i]);
                zonghe_geshu_celan[6] += Convert.ToInt32(tubanshu[6, i]);
                zonghe_geshu_celan[7] += Convert.ToInt32(tubanshu[7, i]);
                zonghe_geshu_celan[8] += Convert.ToInt32(tubanshu[8, i]);
                zonghe_geshu_celan[9] += Convert.ToInt32(tubanshu[9, i]);
                zonghe_geshu_celan[10] += Convert.ToInt32(tubanshu[10, i]);
                zonghe_geshu_celan[11] += Convert.ToInt32(tubanshu[11, i]);
                zonghe_geshu_celan[12] += Convert.ToInt32(tubanshu[12, i]);
                zonghe_geshu_celan[13] += Convert.ToInt32(tubanshu[13, i]);
            }
            for (int i = 0; i < 14; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_geshu_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_geshu[i];
            }
            newTable.Cell(16, 12).Range.Text = Convert.ToString(sum);
            return;
        }

        public void WriteToWord_dbfg_tl_mj(string time)
        {
            OpenWordFile(fileName);
            CreateTable(6, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            for (int i = 8; i <12; i++)
            {
                newTable.Cell(i-6, 1).Range.Text = firstColumn[i];
            }
            newTable.Cell(6, 1).Range.Text = firstColumn[14];

            string[,] mianji = new string[4,10];
            for (int i = 9; i <= 12; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    mianji[i - 9,j - 1] = orcl_W.liaohe_dbfg_mianji(i, time, j);
                }
            }

            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 1, j + 1).Range.Text = mianji[i - 1,j - 1];
                }
            }

            double[] zonghe_mianji = new double[10];
            for (int i = 0; i < 4;i++ )
            {
                zonghe_mianji[0] += Convert.ToDouble(mianji[i, 0]);
                zonghe_mianji[1] += Convert.ToDouble(mianji[i, 1]);
                zonghe_mianji[2] += Convert.ToDouble(mianji[i, 2]);
                zonghe_mianji[3] += Convert.ToDouble(mianji[i, 3]);
                zonghe_mianji[4] += Convert.ToDouble(mianji[i, 4]);
                zonghe_mianji[5] += Convert.ToDouble(mianji[i, 5]);
                zonghe_mianji[6] += Convert.ToDouble(mianji[i, 6]);
                zonghe_mianji[7] += Convert.ToDouble(mianji[i, 7]);
                zonghe_mianji[8] += Convert.ToDouble(mianji[i, 8]);
                zonghe_mianji[9] += Convert.ToDouble(mianji[i, 9]);
              
              
            }
            for (int i = 0; i < 10;i++ )
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_mianji[i]);
            }

            double[] zonghe_mianji_celan = new double[4];
            for (int i = 0; i < 10; i++)
            {
                zonghe_mianji_celan[0] += Convert.ToDouble(mianji[0, i]);
                zonghe_mianji_celan[1] += Convert.ToDouble(mianji[1, i]);
                zonghe_mianji_celan[2] += Convert.ToDouble(mianji[2, i]);
                zonghe_mianji_celan[3] += Convert.ToDouble(mianji[3, i]);
               
            }
            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_mianji_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10;i++ )
            {
                sum += zonghe_mianji[i];
            }
            newTable.Cell(6, 12).Range.Text = Convert.ToString(sum);

            return;
        }
        public void WriteToWord_dbfg_tl_sl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(6, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            for (int i = 8; i < 12; i++)
            {
                newTable.Cell(i - 6, 1).Range.Text = firstColumn[i];
            }
            newTable.Cell(6, 1).Range.Text = firstColumn[14];

            string[,] tubanshu = new string[4,10];
            for (int i = 9; i <= 12; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    tubanshu[i - 9,j - 1] = orcl_W.liaohe_dbfg_tubanshu(i, time, j);
                }
            }
            for (int i = 1; i <= 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 1, j + 1).Range.Text = tubanshu[i - 1,j - 1];
                }
            }

            int[] zonghe_geshu = new int[10];
            for (int i = 0; i < 4; i++)
            {
                zonghe_geshu[0] += Convert.ToInt32(tubanshu[i, 0]);
                zonghe_geshu[1] += Convert.ToInt32(tubanshu[i, 1]);
                zonghe_geshu[2] += Convert.ToInt32(tubanshu[i, 2]);
                zonghe_geshu[3] += Convert.ToInt32(tubanshu[i, 3]);
                zonghe_geshu[4] += Convert.ToInt32(tubanshu[i, 4]);
                zonghe_geshu[5] += Convert.ToInt32(tubanshu[i, 5]);
                zonghe_geshu[6] += Convert.ToInt32(tubanshu[i, 6]);
                zonghe_geshu[7] += Convert.ToInt32(tubanshu[i, 7]);
                zonghe_geshu[8] += Convert.ToInt32(tubanshu[i, 8]);
                zonghe_geshu[9] += Convert.ToInt32(tubanshu[i, 9]);


            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_geshu[i]);
            }

            double[] zonghe_geshu_celan = new double[4];
            for (int i = 0; i < 10; i++)
            {
                zonghe_geshu_celan[0] += Convert.ToDouble(tubanshu[0, i]);
                zonghe_geshu_celan[1] += Convert.ToDouble(tubanshu[1, i]);
                zonghe_geshu_celan[2] += Convert.ToDouble(tubanshu[2, i]);
                zonghe_geshu_celan[3] += Convert.ToDouble(tubanshu[3, i]);

            }
            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_geshu_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_geshu[i];
            }
            newTable.Cell(6, 12).Range.Text = Convert.ToString(sum);
            return;
        }

        public void WriteToWord_dbfg_sy_mj(string time)
        {
            OpenWordFile(fileName);
            CreateTable(7, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 2, 1).Range.Text = firstColumn[i];
            }
            newTable.Cell(7, 1).Range.Text = firstColumn[14];

            string[,] mianji = new string[5,10];
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    mianji[i - 1,j - 1] = orcl_W.liaohe_dbfg_mianji(i, time, j);
                }
            }

            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 1, j + 1).Range.Text = mianji[i - 1,j - 1];
                }
            }

            double[] zonghe_mianji = new double[10];
            for (int i = 0; i < 5; i++)
            {
                zonghe_mianji[0] += Convert.ToDouble(mianji[i, 0]);
                zonghe_mianji[1] += Convert.ToDouble(mianji[i, 1]);
                zonghe_mianji[2] += Convert.ToDouble(mianji[i, 2]);
                zonghe_mianji[3] += Convert.ToDouble(mianji[i, 3]);
                zonghe_mianji[4] += Convert.ToDouble(mianji[i, 4]);
                zonghe_mianji[5] += Convert.ToDouble(mianji[i, 5]);
                zonghe_mianji[6] += Convert.ToDouble(mianji[i, 6]);
                zonghe_mianji[7] += Convert.ToDouble(mianji[i, 7]);
                zonghe_mianji[8] += Convert.ToDouble(mianji[i, 8]);
                zonghe_mianji[9] += Convert.ToDouble(mianji[i, 9]);


            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_mianji[i]);
            }

            double[] zonghe_mianji_celan = new double[5];
            for (int i = 0; i < 10; i++)
            {
                zonghe_mianji_celan[0] += Convert.ToDouble(mianji[0, i]);
                zonghe_mianji_celan[1] += Convert.ToDouble(mianji[1, i]);
                zonghe_mianji_celan[2] += Convert.ToDouble(mianji[2, i]);
                zonghe_mianji_celan[3] += Convert.ToDouble(mianji[3, i]);
                zonghe_mianji_celan[4] += Convert.ToDouble(mianji[4, i]);

            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_mianji_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_mianji[i];
            }
            newTable.Cell(7, 12).Range.Text = Convert.ToString(sum);
            return;
        }
        public void WriteToWord_dbfg_sy_sl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(7, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 2, 1).Range.Text = firstColumn[i];
            }
            newTable.Cell(7, 1).Range.Text = firstColumn[14];

            string[,] tubanshu = new string[5,10];
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    tubanshu[i - 1,j - 1] = orcl_W.liaohe_dbfg_tubanshu(i, time, j);
                }
            }
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 1, j + 1).Range.Text = tubanshu[i - 1,j - 1];
                }
            }

            int[] zonghe_geshu = new int[10];
            for (int i = 0; i < 5; i++)
            {
                zonghe_geshu[0] += Convert.ToInt32(tubanshu[i, 0]);
                zonghe_geshu[1] += Convert.ToInt32(tubanshu[i, 1]);
                zonghe_geshu[2] += Convert.ToInt32(tubanshu[i, 2]);
                zonghe_geshu[3] += Convert.ToInt32(tubanshu[i, 3]);
                zonghe_geshu[4] += Convert.ToInt32(tubanshu[i, 4]);
                zonghe_geshu[5] += Convert.ToInt32(tubanshu[i, 5]);
                zonghe_geshu[6] += Convert.ToInt32(tubanshu[i, 6]);
                zonghe_geshu[7] += Convert.ToInt32(tubanshu[i, 7]);
                zonghe_geshu[8] += Convert.ToInt32(tubanshu[i, 8]);
                zonghe_geshu[9] += Convert.ToInt32(tubanshu[i, 9]);
            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_geshu[i]);
            }

            double[] zonghe_geshu_celan = new double[5];
            for (int i = 0; i < 10; i++)
            {
                zonghe_geshu_celan[0] += Convert.ToInt32(tubanshu[0, i]);
                zonghe_geshu_celan[1] += Convert.ToInt32(tubanshu[1, i]);
                zonghe_geshu_celan[2] += Convert.ToInt32(tubanshu[2, i]);
                zonghe_geshu_celan[3] += Convert.ToInt32(tubanshu[3, i]);
                zonghe_geshu_celan[4] += Convert.ToInt32(tubanshu[4, i]);

            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_geshu_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_geshu[i];
            }
            newTable.Cell(7, 12).Range.Text = Convert.ToString(sum);
            return;
        }

        public void WriteToWord_dbfg_as_mj(string time)
        {
            OpenWordFile(fileName);
            CreateTable(3, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
          
            newTable.Cell(2, 1).Range.Text = firstColumn[5];
            
            newTable.Cell(3, 1).Range.Text = firstColumn[14];

            string[,] mianji = new string[1,10];
            for (int j = 1; j <= 10; j++)
            {
                mianji[0,j - 1] = orcl_W.liaohe_dbfg_mianji(6, time, j);
            }

            for (int j = 1; j <= 10; j++)
            {
                newTable.Cell(2, j + 1).Range.Text = mianji[0,j - 1];
                newTable.Cell(3, j + 1).Range.Text = mianji[0,j - 1];
            }

            double[] zonghe_mianji_celan = new double[1];
            for (int i = 0; i < 10; i++)
            {
                zonghe_mianji_celan[0] += Convert.ToDouble(mianji[0, i]);
             

            }
            for (int i = 0; i <2; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_mianji_celan[0]);
            }
            return;
        }
        public void WriteToWord_dbfg_as_sl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(3, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }
            newTable.Cell(2, 1).Range.Text = firstColumn[5];

            newTable.Cell(3, 1).Range.Text = firstColumn[14];

            string[,] tubanshu = new string[1,10];
            for (int j = 1; j <= 10; j++)
            {
                tubanshu[0,j - 1] = orcl_W.liaohe_dbfg_tubanshu(6, time, j);
            }
            for (int j = 1; j <= 10; j++)
            {
                newTable.Cell(2, j + 1).Range.Text = tubanshu[0,j - 1];
                newTable.Cell(3, j + 1).Range.Text = tubanshu[0,j - 1];
            }

            int[] zonghe_geshu_celan = new int[1];
            for (int i = 0; i < 10; i++)
            {
                zonghe_geshu_celan[0] += Convert.ToInt32(tubanshu[0, i]);


            }
            for (int i = 0; i < 2; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_geshu_celan[0]);
            }
            return;
        }

        public void WriteToWord_dbfg_pj_mj(string time)
        {
            OpenWordFile(fileName);
            CreateTable(6, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }

            newTable.Cell(2, 1).Range.Text = firstColumn[6];
            newTable.Cell(3, 1).Range.Text = firstColumn[7];
            newTable.Cell(4, 1).Range.Text = firstColumn[12];
            newTable.Cell(5, 1).Range.Text = firstColumn[13];
            newTable.Cell(6, 1).Range.Text = firstColumn[14];

            string[,] mianji = new string[4,10];
            for (int j = 1; j <= 10; j++)
            {
                mianji[0,j - 1] = orcl_W.liaohe_dbfg_mianji(7, time, j);
                mianji[1,j - 1] = orcl_W.liaohe_dbfg_mianji(8, time, j);
                mianji[2,j - 1] = orcl_W.liaohe_dbfg_mianji(13, time, j);
                mianji[3,j - 1] = orcl_W.liaohe_dbfg_mianji(14, time, j);
            }

            for (int i = 0; i < 4;i++ )
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i+2, j + 1).Range.Text = mianji[i,j - 1];

                }
            }
            double[] zonghe_mianji = new double[10];
            for (int i = 0; i < 4; i++)
            {
                zonghe_mianji[0] += Convert.ToDouble(mianji[i, 0]);
                zonghe_mianji[1] += Convert.ToDouble(mianji[i, 1]);
                zonghe_mianji[2] += Convert.ToDouble(mianji[i, 2]);
                zonghe_mianji[3] += Convert.ToDouble(mianji[i, 3]);
                zonghe_mianji[4] += Convert.ToDouble(mianji[i, 4]);
                zonghe_mianji[5] += Convert.ToDouble(mianji[i, 5]);
                zonghe_mianji[6] += Convert.ToDouble(mianji[i, 6]);
                zonghe_mianji[7] += Convert.ToDouble(mianji[i, 7]);
                zonghe_mianji[8] += Convert.ToDouble(mianji[i, 8]);
                zonghe_mianji[9] += Convert.ToDouble(mianji[i, 9]);


            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_mianji[i]);
            }

            double[] zonghe_mianji_celan = new double[4];
            for (int i = 0; i < 10; i++)
            {
                zonghe_mianji_celan[0] += Convert.ToDouble(mianji[0, i]);
                zonghe_mianji_celan[1] += Convert.ToDouble(mianji[1, i]);
                zonghe_mianji_celan[2] += Convert.ToDouble(mianji[2, i]);
                zonghe_mianji_celan[3] += Convert.ToDouble(mianji[3, i]);

            }
            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_mianji_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_mianji[i];
            }
            newTable.Cell(6, 12).Range.Text = Convert.ToString(sum);
            return;
        }
        public void WriteToWord_dbfg_pj_sl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(6, 12);
            for (int i = 0; i < 12; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = firstRow[i];
            }

            newTable.Cell(2, 1).Range.Text = firstColumn[6];
            newTable.Cell(3, 1).Range.Text = firstColumn[7];
            newTable.Cell(4, 1).Range.Text = firstColumn[12];
            newTable.Cell(5, 1).Range.Text = firstColumn[13];
            newTable.Cell(6, 1).Range.Text = "总计";

            string[,] tubanshu = new string[4,10];
            for (int j = 1; j <= 10; j++)
            {
                tubanshu[0,j - 1] = orcl_W.liaohe_dbfg_tubanshu(7, time, j);
                tubanshu[1,j - 1] = orcl_W.liaohe_dbfg_tubanshu(8, time, j);
                tubanshu[2,j - 1] = orcl_W.liaohe_dbfg_tubanshu(13, time, j);
                tubanshu[3,j - 1] = orcl_W.liaohe_dbfg_tubanshu(14, time, j);
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    newTable.Cell(i + 2, j + 1).Range.Text = tubanshu[i,j - 1];

                }
            }
            int[] zonghe_geshu = new int[10];
            for (int i = 0; i < 4; i++)
            {
                zonghe_geshu[0] += Convert.ToInt32(tubanshu[i, 0]);
                zonghe_geshu[1] += Convert.ToInt32(tubanshu[i, 1]);
                zonghe_geshu[2] += Convert.ToInt32(tubanshu[i, 2]);
                zonghe_geshu[3] += Convert.ToInt32(tubanshu[i, 3]);
                zonghe_geshu[4] += Convert.ToInt32(tubanshu[i, 4]);
                zonghe_geshu[5] += Convert.ToInt32(tubanshu[i, 5]);
                zonghe_geshu[6] += Convert.ToInt32(tubanshu[i, 6]);
                zonghe_geshu[7] += Convert.ToInt32(tubanshu[i, 7]);
                zonghe_geshu[8] += Convert.ToInt32(tubanshu[i, 8]);
                zonghe_geshu[9] += Convert.ToInt32(tubanshu[i, 9]);


            }
            for (int i = 0; i < 10; i++)
            {
                newTable.Cell(16, i + 2).Range.Text = Convert.ToString(zonghe_geshu[i]);
            }

            double[] zonghe_geshu_celan = new double[4];
            for (int i = 0; i < 10; i++)
            {
                zonghe_geshu_celan[0] += Convert.ToDouble(tubanshu[0, i]);
                zonghe_geshu_celan[1] += Convert.ToDouble(tubanshu[1, i]);
                zonghe_geshu_celan[2] += Convert.ToDouble(tubanshu[2, i]);
                zonghe_geshu_celan[3] += Convert.ToDouble(tubanshu[3, i]);

            }
            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 12).Range.Text = Convert.ToString(zonghe_geshu_celan[i]);
            }

            double sum = 0.0;
            for (int i = 0; i < 10; i++)
            {
                sum += zonghe_geshu[i];
            }
            newTable.Cell(6, 12).Range.Text = Convert.ToString(sum);
            return;
        }

        //国情要素
        public void WriteToWord_gqys_dl(string time)
        {
            OpenWordFile(fileName);
            CreateTable(7, 9);

            newTable.Cell(1, 2).Merge(newTable.Cell(1, 3));
            newTable.Cell(1, 3).Merge(newTable.Cell(1, 4));
            newTable.Cell(1, 4).Merge(newTable.Cell(1, 5));
            newTable.Cell(1, 5).Merge(newTable.Cell(1, 6));

            for (int i = 1; i < 6; i++)
            {
                newTable.Cell(1, i).Range.Text = daoluItem[i - 1];
            }
            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(2, 2 * i).Range.Text = daoluItem[5];
                newTable.Cell(2, 2 * i + 1).Range.Text = daoluItem[6];
            }
            for (int i = 3; i < 7; i++)
            {
                newTable.Cell(i, 1).Range.Text = xingzhengshi[i - 3];
            }
            newTable.Cell(7, 1).Range.Text = daoluItem[7];

            string[] teilu = new string[14];
            string[] gonglu = new string[14];
            string[] chengshidaolulu = new string[14];
            string[] xiangcundaolu = new string[14];

            string[] teilu_L = new string[14];
            string[] gonglu_L = new string[14];
            string[] chengshidaolulu_L = new string[14];
            string[] xiangcundaolu_L = new string[14];

            teilu = orcl_W.getcount_daolu(1);
            gonglu = orcl_W.getcount_daolu(2);
            chengshidaolulu = orcl_W.getcount_daolu(3);
            xiangcundaolu = orcl_W.getcount_daolu(4);

            teilu_L = orcl_W.getlength_daolu(1);
            gonglu_L = orcl_W.getlength_daolu(2);
            chengshidaolulu_L = orcl_W.getlength_daolu(3);
            xiangcundaolu_L = orcl_W.getlength_daolu(4);

            int[] geshu = new int[4];
            double[] lengh = new double[4];
            for (int i = 0; i < 4; i++)
            {
                geshu[i] = 0;
                lengh[i] = 0;
            }
            for (int i = 9; i < 13; i++)
            {
                geshu[0] += Convert.ToInt32(teilu[i - 1]);
                geshu[1] += Convert.ToInt32(gonglu[i - 1]);
                geshu[2] += Convert.ToInt32(chengshidaolulu[i - 1]);
                geshu[3] += Convert.ToInt32(xiangcundaolu[i - 1]);

                lengh[0] += Convert.ToDouble(teilu_L[i - 1]);
                lengh[1] += Convert.ToDouble(gonglu_L[i - 1]);
                lengh[2] += Convert.ToDouble(chengshidaolulu_L[i - 1]);
                lengh[3] += Convert.ToDouble(xiangcundaolu_L[i - 1]);

            }

            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(3, 2 * i).Range.Text = Convert.ToString(geshu[i - 1]);
                newTable.Cell(3, 2 * i + 1).Range.Text = Convert.ToString(lengh[i - 1]);
            }

            for (int i = 0; i < 4; i++)
            {
                geshu[i] = 0;
                lengh[i] = 0;
            }

            for (int i = 1; i < 6; i++)
            {
                geshu[0] += Convert.ToInt32(teilu[i - 1]);
                geshu[1] += Convert.ToInt32(gonglu[i - 1]);
                geshu[2] += Convert.ToInt32(chengshidaolulu[i - 1]);
                geshu[3] += Convert.ToInt32(xiangcundaolu[i - 1]);

                lengh[0] += Convert.ToDouble(teilu_L[i - 1]);
                lengh[1] += Convert.ToDouble(gonglu_L[i - 1]);
                lengh[2] += Convert.ToDouble(chengshidaolulu_L[i - 1]);
                lengh[3] += Convert.ToDouble(xiangcundaolu_L[i - 1]);
            }

            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(4, 2 * i).Range.Text = Convert.ToString(geshu[i - 1]);
                newTable.Cell(4, 2 * i + 1).Range.Text = Convert.ToString(lengh[i - 1]);
            }

            for (int i = 0; i < 4; i++)
            {
                geshu[i] = 0;
                lengh[i] = 0;
            }
            geshu[0] += Convert.ToInt32(teilu[5]);
            geshu[1] += Convert.ToInt32(gonglu[5]);
            geshu[2] += Convert.ToInt32(chengshidaolulu[5]);
            geshu[3] += Convert.ToInt32(xiangcundaolu[5]);

            lengh[0] += Convert.ToDouble(teilu_L[5]);
            lengh[1] += Convert.ToDouble(gonglu_L[5]);
            lengh[2] += Convert.ToDouble(chengshidaolulu_L[5]);
            lengh[3] += Convert.ToDouble(xiangcundaolu_L[5]);

            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(5, 2 * i).Range.Text = Convert.ToString(geshu[i - 1]);
                newTable.Cell(5, 2 * i + 1).Range.Text = Convert.ToString(lengh[i - 1]);
            }

            for (int i = 0; i < 4; i++)
            {
                geshu[i] = 0;
                lengh[i] = 0;
            }
            geshu[0] = Convert.ToInt32(teilu[6]) + Convert.ToInt32(teilu[7]) + Convert.ToInt32(teilu[12]) + Convert.ToInt32(teilu[13]);
            geshu[1] = Convert.ToInt32(gonglu[6]) + Convert.ToInt32(gonglu[7]) + Convert.ToInt32(gonglu[12]) + Convert.ToInt32(gonglu[13]);
            geshu[2] = Convert.ToInt32(chengshidaolulu[6]) + Convert.ToInt32(chengshidaolulu[7]) + Convert.ToInt32(chengshidaolulu[12]) + Convert.ToInt32(chengshidaolulu[13]);
            geshu[3] = Convert.ToInt32(xiangcundaolu[6]) + Convert.ToInt32(xiangcundaolu[7]) + Convert.ToInt32(xiangcundaolu[12]) + Convert.ToInt32(xiangcundaolu[13]);

            lengh[0] = Convert.ToDouble(teilu_L[6]) + Convert.ToDouble(teilu_L[7]) + Convert.ToDouble(teilu_L[12]) + Convert.ToDouble(teilu_L[13]);
            lengh[1] = Convert.ToDouble(gonglu_L[6]) + Convert.ToDouble(gonglu_L[7]) + Convert.ToDouble(gonglu_L[12]) + Convert.ToDouble(gonglu_L[13]);
            lengh[2] = Convert.ToDouble(chengshidaolulu_L[6]) + Convert.ToDouble(chengshidaolulu_L[7]) + Convert.ToDouble(chengshidaolulu_L[12]) + Convert.ToDouble(chengshidaolulu_L[13]);
            lengh[3] = Convert.ToDouble(xiangcundaolu_L[6]) + Convert.ToDouble(xiangcundaolu_L[7]) + Convert.ToDouble(xiangcundaolu_L[12]) + Convert.ToDouble(xiangcundaolu_L[13]);

            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(6, 2 * i).Range.Text = Convert.ToString(geshu[i - 1]);
                newTable.Cell(6, 2 * i + 1).Range.Text = Convert.ToString(lengh[i - 1]);
            }
            int temp_1 = 0;
            double temp_2 = 0.0;
            int temp_3 = 0;
            double temp_4 = 0.0;
            int temp_5 = 0;
            double temp_6 = 0.0;
            int temp_7 = 0;
            double temp_8 = 0.0;

            string[] getCellValues_1 = new string[4];
            string[] getCellValues_2 = new string[4];
            string[] getCellValues_3 = new string[4];
            string[] getCellValues_4 = new string[4];
            string[] getCellValues_5 = new string[4];
            string[] getCellValues_6 = new string[4];
            string[] getCellValues_7 = new string[4];
            string[] getCellValues_8 = new string[4];

            for (int i = 0; i < 4;i++ )
            {
                getCellValues_1[i] = newTable.Cell(i + 3, 2).Range.Text.ToString();
                getCellValues_1[i] = getCellValues_1[i].Substring(0, getCellValues_1[i].Length - 2);
                temp_1 += Convert.ToInt32(getCellValues_1[i]);

                getCellValues_2[i] = newTable.Cell(i + 3, 3).Range.Text.ToString();
                getCellValues_2[i] = getCellValues_2[i].Substring(0, getCellValues_2[i].Length - 2);
                temp_2 += Convert.ToDouble(getCellValues_2[i]);

                getCellValues_3[i] = newTable.Cell(i + 3, 4).Range.Text.ToString();
                getCellValues_3[i] = getCellValues_3[i].Substring(0, getCellValues_3[i].Length - 2);
                temp_3 += Convert.ToInt32(getCellValues_3[i]);

                getCellValues_4[i] = newTable.Cell(i + 3, 5).Range.Text.ToString();
                getCellValues_4[i] = getCellValues_4[i].Substring(0, getCellValues_4[i].Length - 2);
                temp_4 += Convert.ToDouble(getCellValues_4[i]);

                getCellValues_5[i] = newTable.Cell(i + 3, 6).Range.Text.ToString();
                getCellValues_5[i] = getCellValues_5[i].Substring(0, getCellValues_5[i].Length - 2);
                temp_5 += Convert.ToInt32(getCellValues_5[i]);

                getCellValues_6[i] = newTable.Cell(i + 3, 7).Range.Text.ToString();
                getCellValues_6[i] = getCellValues_6[i].Substring(0, getCellValues_6[i].Length - 2);
                temp_6 += Convert.ToDouble(getCellValues_6[i]);

                getCellValues_7[i] = newTable.Cell(i + 3, 8).Range.Text.ToString();
                getCellValues_7[i] = getCellValues_7[i].Substring(0, getCellValues_7[i].Length - 2);
                temp_7 += Convert.ToInt32(getCellValues_7[i]);

                getCellValues_8[i] = newTable.Cell(i + 3, 9).Range.Text.ToString();
                getCellValues_8[i] = getCellValues_8[i].Substring(0, getCellValues_8[i].Length - 2);
                temp_8 += Convert.ToDouble(getCellValues_8[i]);

            }
            newTable.Cell(7, 2).Range.Text = Convert.ToString(temp_1);
            newTable.Cell(7, 3).Range.Text = Convert.ToString(temp_2);
            newTable.Cell(7, 4).Range.Text = Convert.ToString(temp_3);
            newTable.Cell(7, 5).Range.Text = Convert.ToString(temp_4);

            newTable.Cell(7, 6).Range.Text = Convert.ToString(temp_5);
            newTable.Cell(7, 7).Range.Text = Convert.ToString(temp_6);
            newTable.Cell(7, 8).Range.Text = Convert.ToString(temp_7);
            newTable.Cell(7, 9).Range.Text = Convert.ToString(temp_8);
           

            return;
        }
        public void WriteToWord_gqys_gzw(string time)
        {
            OpenWordFile(fileName);
            CreateTable(7, 7);

            for (int i = 1; i < 8; i++)
            {
                newTable.Cell(1, i).Range.Text = gouzhuwuItem[i - 1];
            }
            newTable.Cell(2, 2).Range.Text = gouzhuwuItem[7];
            newTable.Cell(7, 1).Range.Text = gouzhuwuItem[9];
            for (int i = 3; i < 8; i++)
            {
                newTable.Cell(2, i).Range.Text = gouzhuwuItem[8];
            }
            for (int i = 3; i < 7; i++)
            {
                newTable.Cell(i, 1).Range.Text = xingzhengshi[i - 3];
            }

            string[][] resault = new string[6][];

            resault[0] = orcl_W.getResultof_gouzhuwu(0721, Convert.ToInt32(orcl1.time));
            resault[1] = orcl_W.getResultof_gouzhuwu(0722, Convert.ToInt32(orcl1.time));
            resault[2] = orcl_W.getResultof_gouzhuwu(0723, Convert.ToInt32(orcl1.time));
            resault[3] = orcl_W.getResultof_gouzhuwu(0732, Convert.ToInt32(orcl1.time));
            resault[4] = orcl_W.getResultof_gouzhuwu(0735, Convert.ToInt32(orcl1.time));
            resault[5] = orcl_W.getResultof_gouzhuwu(0736, Convert.ToInt32(orcl1.time));

            double[] changdu = new double[4];
            int[][] yaosu = new int[5][];
            yaosu[0] = new int[14];
            yaosu[1] = new int[14];
            yaosu[2] = new int[14];
            yaosu[3] = new int[14];
            yaosu[4] = new int[14];

            for (int i = 9; i < 13; i++)//铁岭
            {
                changdu[0] += Math.Round(Convert.ToDouble(resault[0][i - 1]) / 1000, 2);
                yaosu[0][0] += Convert.ToInt32(resault[1][i - 1]);
                yaosu[1][0] += Convert.ToInt32(resault[2][i - 1]);
                yaosu[2][0] += Convert.ToInt32(resault[3][i - 1]);
                yaosu[3][0] += Convert.ToInt32(resault[4][i - 1]);
                yaosu[4][0] += Convert.ToInt32(resault[5][i - 1]);

            }

            for (int i = 1; i < 6; i++)//沈阳
            {
                changdu[1] += Math.Round(Convert.ToDouble(resault[0][i - 1]) / 1000, 2);
                yaosu[0][1] += Convert.ToInt32(resault[1][i - 1]);
                yaosu[1][1] += Convert.ToInt32(resault[2][i - 1]);
                yaosu[2][1] += Convert.ToInt32(resault[3][i - 1]);
                yaosu[3][1] += Convert.ToInt32(resault[4][i - 1]);
                yaosu[4][1] += Convert.ToInt32(resault[5][i - 1]);
            }
            changdu[2] += Math.Round(Convert.ToDouble(resault[0][5]) / 1000, 2);
            yaosu[0][2] += Convert.ToInt32(resault[1][5]);
            yaosu[1][2] += Convert.ToInt32(resault[2][5]);
            yaosu[2][2] += Convert.ToInt32(resault[3][5]);
            yaosu[3][2] += Convert.ToInt32(resault[4][5]);
            yaosu[4][2] += Convert.ToInt32(resault[5][5]);

            changdu[3] = Math.Round(Convert.ToDouble(resault[0][6]) / 1000, 2) + Math.Round(Convert.ToDouble(resault[0][7]) / 1000, 2) + Math.Round(Convert.ToDouble(resault[0][12]) / 1000, 2) + Math.Round(Convert.ToDouble(resault[0][13]) / 1000, 2);
            yaosu[0][3] = Convert.ToInt32(resault[1][6]) + Convert.ToInt32(resault[1][7]) + Convert.ToInt32(resault[1][12]) + Convert.ToInt32(resault[1][13]);
            yaosu[1][3] = Convert.ToInt32(resault[2][6]) + Convert.ToInt32(resault[2][7]) + Convert.ToInt32(resault[2][12]) + Convert.ToInt32(resault[2][13]);
            yaosu[2][3] = Convert.ToInt32(resault[3][6]) + Convert.ToInt32(resault[3][7]) + Convert.ToInt32(resault[3][12]) + Convert.ToInt32(resault[3][13]);
            yaosu[3][3] = Convert.ToInt32(resault[4][6]) + Convert.ToInt32(resault[4][7]) + Convert.ToInt32(resault[4][12]) + Convert.ToInt32(resault[4][13]);
            yaosu[4][3] = Convert.ToInt32(resault[5][6]) + Convert.ToInt32(resault[5][7]) + Convert.ToInt32(resault[5][12]) + Convert.ToInt32(resault[5][13]);

            for (int i = 3; i < 7; i++)
            {
                newTable.Cell(i, 2).Range.Text = Convert.ToString(changdu[i - 3]);
                newTable.Cell(i, 3).Range.Text = Convert.ToString(yaosu[0][i - 3]);
                newTable.Cell(i, 4).Range.Text = Convert.ToString(yaosu[1][i - 3]);
                newTable.Cell(i, 5).Range.Text = Convert.ToString(yaosu[2][i - 3]);
                newTable.Cell(i, 6).Range.Text = Convert.ToString(yaosu[3][i - 3]);
                newTable.Cell(i, 7).Range.Text = Convert.ToString(yaosu[4][i - 3]);

            }

            double temp_1 = 0;
            int temp_2 = 0;
            int temp_3 = 0;
            int temp_4 = 0;
            int temp_5 = 0;
            int temp_6 = 0;
         

            string[] getCellValues_1 = new string[4];
            string[] getCellValues_2 = new string[4];
            string[] getCellValues_3 = new string[4];
            string[] getCellValues_4 = new string[4];
            string[] getCellValues_5 = new string[4];
            string[] getCellValues_6 = new string[4];


            for (int i = 0; i < 4; i++)
            {
                getCellValues_1[i] = newTable.Cell(i + 3, 2).Range.Text.ToString();
                getCellValues_1[i] = getCellValues_1[i].Substring(0, getCellValues_1[i].Length - 2);
                temp_1 += Convert.ToDouble(getCellValues_1[i]);

                getCellValues_2[i] = newTable.Cell(i + 3, 3).Range.Text.ToString();
                getCellValues_2[i] = getCellValues_2[i].Substring(0, getCellValues_2[i].Length - 2);
                temp_2 += Convert.ToInt32(getCellValues_2[i]);

                getCellValues_3[i] = newTable.Cell(i + 3, 4).Range.Text.ToString();
                getCellValues_3[i] = getCellValues_3[i].Substring(0, getCellValues_3[i].Length - 2);
                temp_3 += Convert.ToInt32(getCellValues_3[i]);

                getCellValues_4[i] = newTable.Cell(i + 3, 5).Range.Text.ToString();
                getCellValues_4[i] = getCellValues_4[i].Substring(0, getCellValues_4[i].Length - 2);
                temp_4 += Convert.ToInt32(getCellValues_4[i]);

                getCellValues_5[i] = newTable.Cell(i + 3, 6).Range.Text.ToString();
                getCellValues_5[i] = getCellValues_5[i].Substring(0, getCellValues_5[i].Length - 2);
                temp_5 += Convert.ToInt32(getCellValues_5[i]);

                getCellValues_6[i] = newTable.Cell(i + 3, 7).Range.Text.ToString();
                getCellValues_6[i] = getCellValues_6[i].Substring(0, getCellValues_6[i].Length - 2);
                temp_6 += Convert.ToInt32(getCellValues_6[i]);

             
            }
            newTable.Cell(7, 2).Range.Text = Convert.ToString(temp_1);
            newTable.Cell(7, 3).Range.Text = Convert.ToString(temp_2);
            newTable.Cell(7, 4).Range.Text = Convert.ToString(temp_3);
            newTable.Cell(7, 5).Range.Text = Convert.ToString(temp_4);

            newTable.Cell(7, 6).Range.Text = Convert.ToString(temp_5);
            newTable.Cell(7, 7).Range.Text = Convert.ToString(temp_6);
            return;
        }
        public void WriteToWord_gqys_sy(string time)
        {
            OpenWordFile(fileName);
            CreateTable(7, 6);

            newTable.Cell(1, 2).Merge(newTable.Cell(1, 3));
            newTable.Cell(1, 3).Merge(newTable.Cell(1, 4));

            for (int i = 1; i < 5; i++)
            {
                newTable.Cell(1, i).Range.Text = shuiyuItem[i - 1];
            }
            newTable.Cell(2, 2).Range.Text = shuiyuItem[4];
            newTable.Cell(2, 3).Range.Text = shuiyuItem[5];
            newTable.Cell(2, 4).Range.Text = shuiyuItem[4];
            newTable.Cell(2, 5).Range.Text = shuiyuItem[5];
            newTable.Cell(2, 6).Range.Text = shuiyuItem[4];

            for (int i = 3; i < 7; i++)
            {
                newTable.Cell(i, 1).Range.Text = xingzhengshi[i - 3];
            }
            newTable.Cell(7, 1).Range.Text = shuiyuItem[6];

            string[] hl_C = new string[14];
            string[] hl_L = new string[14];
            string[] sq_C = new string[14];
            string[] sq_L = new string[14];
            string[] sk_C = new string[14];

            hl_C = orcl_W.getResult_shuiyu(1011, Convert.ToInt32(orcl1.time), 1);
            hl_L = orcl_W.getResult_shuiyu(1011, Convert.ToInt32(orcl1.time), 2);
            sq_C = orcl_W.getResult_shuiyu(1012, Convert.ToInt32(orcl1.time), 1);
            sq_L = orcl_W.getResult_shuiyu(1012, Convert.ToInt32(orcl1.time), 2);

            sk_C = orcl_W.getResult_shuiyu(1031, Convert.ToInt32(orcl1.time), 1);

            int[] xs_hl_C = new int[4];
            double[] xs_hl_L = new double[4];

            int[] xs_sq_C = new int[4];
            double[] xs_sq_L = new double[4];

            int[] xs_sk_C = new int[4];

            for (int i = 9; i < 13; i++)//铁岭
            {
                xs_hl_C[0] += Convert.ToInt32(hl_C[i - 1]);
                xs_hl_L[0] += Convert.ToDouble(hl_L[i - 1]);
                xs_sq_C[0] += Convert.ToInt32(sq_C[i - 1]);
                xs_sq_L[0] += Convert.ToDouble(sq_L[i - 1]);
                xs_sk_C[0] += Convert.ToInt32(sk_C[i - 1]);
            }
            for (int i = 1; i < 6; i++)//沈阳
            {
                xs_hl_C[1] += Convert.ToInt32(hl_C[i - 1]);
                xs_hl_L[1] += Convert.ToDouble(hl_L[i - 1]);
                xs_sq_C[1] += Convert.ToInt32(sq_C[i - 1]);
                xs_sq_L[1] += Convert.ToDouble(sq_L[i - 1]);
                xs_sk_C[1] += Convert.ToInt32(sk_C[i - 1]);
            }
            xs_hl_C[2] += Convert.ToInt32(hl_C[5]);
            xs_hl_L[2] += Convert.ToDouble(hl_L[5]);
            xs_sq_C[2] += Convert.ToInt32(sq_C[5]);
            xs_sq_L[2] += Convert.ToDouble(sq_L[5]);
            xs_sk_C[2] += Convert.ToInt32(sk_C[5]);


            xs_hl_C[3] = Convert.ToInt32(hl_C[6]) + Convert.ToInt32(hl_C[7]) + Convert.ToInt32(hl_C[12]) + Convert.ToInt32(hl_C[13]);
            xs_hl_L[3] = Convert.ToDouble(hl_L[6]) + Convert.ToDouble(hl_L[7]) + Convert.ToDouble(hl_L[12]) + Convert.ToDouble(hl_L[13]);
            xs_sq_C[3] = Convert.ToInt32(sq_C[6]) + Convert.ToInt32(sq_C[7]) + Convert.ToInt32(sq_C[12]) + Convert.ToInt32(sq_C[13]);
            xs_sq_L[3] = Convert.ToDouble(sq_L[6]) + Convert.ToDouble(sq_L[7]) + Convert.ToDouble(sq_L[12]) + Convert.ToDouble(sq_L[13]);
            xs_sk_C[3] = Convert.ToInt32(sk_C[6]) + Convert.ToInt32(sk_C[7]) + Convert.ToInt32(sk_C[12]) + Convert.ToInt32(sk_C[13]);


            for (int i = 3; i < 7; i++)
            {
                newTable.Cell(i, 2).Range.Text = Convert.ToString(xs_hl_C[i - 3]);
                newTable.Cell(i, 3).Range.Text = Convert.ToString(xs_hl_L[i - 3]);
                newTable.Cell(i, 4).Range.Text = Convert.ToString(xs_sq_C[i - 3]);
                newTable.Cell(i, 5).Range.Text = Convert.ToString(xs_sq_L[i - 3]);
                newTable.Cell(i, 6).Range.Text = Convert.ToString(xs_sk_C[i - 3]);
            }

            int temp_1 = 0;
            double temp_2 = 0.0;
            int temp_3 = 0;
            double temp_4 = 0.0;
            int temp_5 = 0;
            
            string[] getCellValues_1 = new string[4];
            string[] getCellValues_2 = new string[4];
            string[] getCellValues_3 = new string[4];
            string[] getCellValues_4 = new string[4];
            string[] getCellValues_5 = new string[4];
        

            for (int i = 0; i < 4; i++)
            {
                getCellValues_1[i] = newTable.Cell(i + 3, 2).Range.Text.ToString();
                getCellValues_1[i] = getCellValues_1[i].Substring(0, getCellValues_1[i].Length - 2);
                temp_1 += Convert.ToInt32(getCellValues_1[i]);

                getCellValues_2[i] = newTable.Cell(i + 3, 3).Range.Text.ToString();
                getCellValues_2[i] = getCellValues_2[i].Substring(0, getCellValues_2[i].Length - 2);
                temp_2 += Convert.ToDouble(getCellValues_2[i]);

                getCellValues_3[i] = newTable.Cell(i + 3, 4).Range.Text.ToString();
                getCellValues_3[i] = getCellValues_3[i].Substring(0, getCellValues_3[i].Length - 2);
                temp_3 += Convert.ToInt32(getCellValues_3[i]);

                getCellValues_4[i] = newTable.Cell(i + 3, 5).Range.Text.ToString();
                getCellValues_4[i] = getCellValues_4[i].Substring(0, getCellValues_4[i].Length - 2);
                temp_4 += Convert.ToDouble(getCellValues_4[i]);

                getCellValues_5[i] = newTable.Cell(i + 3, 6).Range.Text.ToString();
                getCellValues_5[i] = getCellValues_5[i].Substring(0, getCellValues_5[i].Length - 2);
                temp_5 += Convert.ToInt32(getCellValues_5[i]);


            }
            newTable.Cell(7, 2).Range.Text = Convert.ToString(temp_1);
            newTable.Cell(7, 3).Range.Text = Convert.ToString(temp_2);
            newTable.Cell(7, 4).Range.Text = Convert.ToString(temp_3);
            newTable.Cell(7, 5).Range.Text = Convert.ToString(temp_4);

            newTable.Cell(7, 6).Range.Text = Convert.ToString(temp_5);
       
            return;
        }
        public void WriteToWord_gqys_dldy(string time)
        {
            OpenWordFile(fileName);
            CreateTable(6, 6);
            for (int i = 0; i < 6; i++)
            {
                newTable.Cell(1, i + 1).Range.Text = dilidanyuanItem[i];
            }
            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 1).Range.Text = xingzhengshi[i];
            }
            newTable.Cell(6, 1).Range.Text = "总计";
            //getResult_dilidanyuan(int table, string nianfen, string cc)
            
            string[] juzhuxiaoqu = orcl_W.getResult_dilidanyuan(3, time, "1141");
            string[] gongkuangqiye = orcl_W.getResult_dilidanyuan(3, time, "1142");
            string[] xingzhengcun = orcl_W.getResult_dilidanyuan(1, time, "Null");
            string[] danweiyuanluo = orcl_W.getResult_dilidanyuan(3, time, "1143");
            string[] fengjing = orcl_W.getResult_dilidanyuan(2, time, "Null");

            int[] fengjing_i = new int[4];
            int[] juzhuxiaoqu_i =new int[4];
            int[] gongkuangqiye_i=new int[4];
            int[] xingzhengcun_i= new int[4];
            int[] danweiyuanluo_i = new int[4];

            for (int i = 9; i < 13; i++)//铁岭
            {
                fengjing_i[0] += Convert.ToInt32(fengjing[i-1]);
                juzhuxiaoqu_i[0] += Convert.ToInt32(juzhuxiaoqu[i - 1]);
                gongkuangqiye_i[0] += Convert.ToInt32(gongkuangqiye[i - 1]);
                xingzhengcun_i[0] += Convert.ToInt32(xingzhengcun[i - 1]);
                danweiyuanluo_i[0] += Convert.ToInt32(danweiyuanluo[i - 1]);

            }
           
            for (int i = 1; i < 6; i++)//沈阳
            {
                fengjing_i[1] += Convert.ToInt32(fengjing[i - 1]);
                juzhuxiaoqu_i[1] += Convert.ToInt32(juzhuxiaoqu[i - 1]);
                gongkuangqiye_i[1] += Convert.ToInt32(gongkuangqiye[i - 1]);
                xingzhengcun_i[1] += Convert.ToInt32(xingzhengcun[i - 1]);
                danweiyuanluo_i[1] += Convert.ToInt32(danweiyuanluo[i - 1]);
            }

            fengjing_i[2] = Convert.ToInt32(fengjing[5]);
            juzhuxiaoqu_i[2] = Convert.ToInt32(juzhuxiaoqu[5]);
            gongkuangqiye_i[2] = Convert.ToInt32(gongkuangqiye[5]);
            xingzhengcun_i[2] = Convert.ToInt32(xingzhengcun[5]);
            danweiyuanluo_i[2] = Convert.ToInt32(danweiyuanluo[5]);

            fengjing_i[3] = Convert.ToInt32(fengjing[6]) + Convert.ToInt32(fengjing[7]) + Convert.ToInt32(fengjing[12]) + Convert.ToInt32(fengjing[13]);
            juzhuxiaoqu_i[3] = Convert.ToInt32(juzhuxiaoqu[6]) + Convert.ToInt32(juzhuxiaoqu[7]) + Convert.ToInt32(juzhuxiaoqu[12]) + Convert.ToInt32(juzhuxiaoqu[13]);
            gongkuangqiye_i[3] = Convert.ToInt32(gongkuangqiye[6]) + Convert.ToInt32(gongkuangqiye[7]) + Convert.ToInt32(gongkuangqiye[12]) + Convert.ToInt32(gongkuangqiye[13]);
            xingzhengcun_i[3] = Convert.ToInt32(xingzhengcun[6]) + Convert.ToInt32(xingzhengcun[7]) + Convert.ToInt32(xingzhengcun[12]) + Convert.ToInt32(xingzhengcun[13]);
            danweiyuanluo_i[3] = Convert.ToInt32(danweiyuanluo[6]) + Convert.ToInt32(danweiyuanluo[7]) + Convert.ToInt32(danweiyuanluo[12]) + Convert.ToInt32(danweiyuanluo[13]);




            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 2).Range.Text = Convert.ToString(fengjing_i[i]);
                newTable.Cell(i + 2, 3).Range.Text = Convert.ToString(juzhuxiaoqu_i[i]);
                newTable.Cell(i + 2, 4).Range.Text = Convert.ToString(gongkuangqiye_i[i]);
                newTable.Cell(i + 2, 5).Range.Text = Convert.ToString(xingzhengcun_i[i]);
                newTable.Cell(i + 2, 6).Range.Text = Convert.ToString(danweiyuanluo_i[i]);
            }


            int temp_1 = 0;
            int temp_2 = 0;
            int temp_3 = 0;
            int temp_4 = 0;
            int temp_5 = 0;

            string[] getCellValues_1 = new string[4];
            string[] getCellValues_2 = new string[4];
            string[] getCellValues_3 = new string[4];
            string[] getCellValues_4 = new string[4];
            string[] getCellValues_5 = new string[4];


            for (int i = 0; i < 4; i++)
            {
                getCellValues_1[i] = newTable.Cell(i + 2, 2).Range.Text.ToString();
                getCellValues_1[i] = getCellValues_1[i].Substring(0, getCellValues_1[i].Length - 2);
                temp_1 += Convert.ToInt32(getCellValues_1[i]);

                getCellValues_2[i] = newTable.Cell(i + 2, 3).Range.Text.ToString();
                getCellValues_2[i] = getCellValues_2[i].Substring(0, getCellValues_2[i].Length - 2);
                temp_2 += Convert.ToInt32(getCellValues_2[i]);

                getCellValues_3[i] = newTable.Cell(i + 2, 4).Range.Text.ToString();
                getCellValues_3[i] = getCellValues_3[i].Substring(0, getCellValues_3[i].Length - 2);
                temp_3 += Convert.ToInt32(getCellValues_3[i]);

                getCellValues_4[i] = newTable.Cell(i + 2, 5).Range.Text.ToString();
                getCellValues_4[i] = getCellValues_4[i].Substring(0, getCellValues_4[i].Length - 2);
                temp_4 += Convert.ToInt32(getCellValues_4[i]);

                getCellValues_5[i] = newTable.Cell(i + 2, 6).Range.Text.ToString();
                getCellValues_5[i] = getCellValues_5[i].Substring(0, getCellValues_5[i].Length - 2);
                temp_5 += Convert.ToInt32(getCellValues_5[i]);


            }
            newTable.Cell(6, 2).Range.Text = Convert.ToString(temp_1);
            newTable.Cell(6, 3).Range.Text = Convert.ToString(temp_2);
            newTable.Cell(6, 4).Range.Text = Convert.ToString(temp_3);
            newTable.Cell(6, 5).Range.Text = Convert.ToString(temp_4);
                         
            newTable.Cell(6, 6).Range.Text = Convert.ToString(temp_5);
       





            return;
        }

        //专题分析
        public void WriteToWord_ztfx_wl_gll()
        {
            OpenWordFile(fileName);
            CreateTable(16, 6);
            newTable.Cell(1, 1).Merge(newTable.Cell(2, 1));
            newTable.Cell(1, 2).Merge(newTable.Cell(2, 2));
            newTable.Cell(1, 5).Merge(newTable.Cell(2, 5));
            newTable.Cell(1, 6).Merge(newTable.Cell(2, 6));
            newTable.Cell(1, 3).Merge(newTable.Cell(1, 4));

            newTable.Cell(3, 1).Merge(newTable.Cell(6, 1));
            newTable.Cell(3, 5).Merge(newTable.Cell(6, 5));

            newTable.Cell(7, 1).Merge(newTable.Cell(11, 1));
            newTable.Cell(7, 5).Merge(newTable.Cell(11, 5));

            newTable.Cell(13, 1).Merge(newTable.Cell(16, 1));
            newTable.Cell(13, 5).Merge(newTable.Cell(16, 5));

            newTable.Cell(3, 6).Merge(newTable.Cell(16, 6));


            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(3, 1).Range.Text = Column1[1];
            newTable.Cell(7, 1).Range.Text = Column1[2];
            newTable.Cell(12, 1).Range.Text = Column1[3];
            newTable.Cell(13, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 3; i < 17; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 2];
            }
            newTable.Cell(1, 3).Range.Text = Item[0];
            newTable.Cell(2, 3).Range.Text = Item[1];
            newTable.Cell(2, 4).Range.Text = Item[2];
            newTable.Cell(1, 4).Range.Text = Item[3];
            newTable.Cell(1, 5).Range.Text = Item[4];


            geshu_yaosu = orcl_W.getCountOfyaosu(orcl1.yaosu, orcl1.time);
            changdu_yaosu = orcl_W.getChangduOfyaosu(orcl1.yaosu, orcl1.time);
            xiaojichangdu = orcl_W.xiaoji_yaosu();
            for (int i = 0; i < 14; i++)
            {
                newTable.Cell(i + 3, 3).Range.Text = geshu_yaosu[i];
                newTable.Cell(i + 3, 4).Range.Text = changdu_yaosu[i];
            }
            newTable.Cell(3, 5).Range.Text = xiaojichangdu[0];
            newTable.Cell(7, 5).Range.Text = xiaojichangdu[1];
            newTable.Cell(12, 5).Range.Text = xiaojichangdu[2];
            newTable.Cell(13, 5).Range.Text = xiaojichangdu[3];
            Double zongji = 0.0;
            for (int i = 0; i < 4; i++)
            {
                zongji += Convert.ToDouble(xiaojichangdu[i]);
            }
            string heji = Convert.ToString(zongji);
            newTable.Cell(3, 6).Range.Text = heji;
            return;
        }
        public void WriteToWord_ztfx_csc()
        {
            OpenWordFile(fileName);
            CreateTable(16, 8);

            newTable.Cell(1, 1).Merge(newTable.Cell(2, 1));
            newTable.Cell(1, 2).Merge(newTable.Cell(2, 2));
            newTable.Cell(1, 3).Merge(newTable.Cell(1, 4));
            newTable.Cell(1, 4).Merge(newTable.Cell(1, 5));
            newTable.Cell(1, 5).Merge(newTable.Cell(1, 6));

            newTable.Cell(3, 1).Merge(newTable.Cell(6, 1));
            newTable.Cell(3, 5).Merge(newTable.Cell(6, 5));
            newTable.Cell(3, 6).Merge(newTable.Cell(6, 6));

            newTable.Cell(7, 1).Merge(newTable.Cell(11, 1));
            newTable.Cell(7, 5).Merge(newTable.Cell(11, 5));
            newTable.Cell(7, 6).Merge(newTable.Cell(11, 6));

            newTable.Cell(13, 1).Merge(newTable.Cell(16, 1));
            newTable.Cell(13, 5).Merge(newTable.Cell(16, 5));
            newTable.Cell(13, 6).Merge(newTable.Cell(16, 6));

            newTable.Cell(3, 7).Merge(newTable.Cell(16, 7));
            newTable.Cell(3, 8).Merge(newTable.Cell(16, 8));

            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(3, 1).Range.Text = Column1[1];
            newTable.Cell(7, 1).Range.Text = Column1[2];
            newTable.Cell(12, 1).Range.Text = Column1[3];
            newTable.Cell(13, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 3; i < 17; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 2];
            }
            newTable.Cell(1, 3).Range.Text = Item[0];
            newTable.Cell(2, 3).Range.Text = Item[5];
            newTable.Cell(2, 4).Range.Text = Item[6];
            newTable.Cell(1, 4).Range.Text = Item[7];
            newTable.Cell(1, 5).Range.Text = Item[8];
            newTable.Cell(2, 5).Range.Text = Item[5];
            newTable.Cell(2, 6).Range.Text = Item[6];
            newTable.Cell(2, 7).Range.Text = Item[5];
            newTable.Cell(2, 8).Range.Text = Item[6];

            geshu_yaosu = orcl_W.getCountOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
            string[] mingji_yaosu = orcl_W.getMianjiOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
            xiaojichangdu = orcl_W.xiaoji_yaosu();

            for (int i = 0; i < 14; i++)
            {
                newTable.Cell(i + 3, 3).Range.Text = geshu_yaosu[i];
                newTable.Cell(i + 3, 4).Range.Text = mingji_yaosu[i];
            }

            newTable.Cell(3, 5).Range.Text = xiaojichangdu[4];
            newTable.Cell(7, 5).Range.Text = xiaojichangdu[5];
            newTable.Cell(12, 5).Range.Text = xiaojichangdu[6];
            newTable.Cell(13, 5).Range.Text = xiaojichangdu[7];

            newTable.Cell(3, 6).Range.Text = xiaojichangdu[0];
            newTable.Cell(7, 6).Range.Text = xiaojichangdu[1];
            newTable.Cell(12, 6).Range.Text = xiaojichangdu[2];
            newTable.Cell(13, 6).Range.Text = xiaojichangdu[3];

            int zongji = 0;
            for (int i = 4; i < 8; i++)
            {
                zongji += Convert.ToInt32(xiaojichangdu[i]);
            }
            string hejishu = Convert.ToString(zongji);
            newTable.Cell(3, 7).Range.Text = hejishu;

            Double zongji1 = 0.0;
            for (int i = 0; i < 4; i++)
            {
                zongji1 += Convert.ToDouble(xiaojichangdu[i]);
            }
            string hejimian = Convert.ToString(zongji1);
            newTable.Cell(3, 8).Range.Text = hejimian;
            return;
        }
        public void WriteToWord_ztfx_hdl()
        {
            OpenWordFile(fileName);
            CreateTable(15, 5);

            newTable.Cell(2, 1).Merge(newTable.Cell(5, 1));
            newTable.Cell(2, 4).Merge(newTable.Cell(5, 4));

            newTable.Cell(6, 1).Merge(newTable.Cell(10, 1));
            newTable.Cell(6, 4).Merge(newTable.Cell(10, 4));

            newTable.Cell(12, 1).Merge(newTable.Cell(15, 1));
            newTable.Cell(12, 4).Merge(newTable.Cell(15, 4));

            newTable.Cell(2, 5).Merge(newTable.Cell(15, 5));

            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(2, 1).Range.Text = Column1[1];
            newTable.Cell(6, 1).Range.Text = Column1[2];
            newTable.Cell(11, 1).Range.Text = Column1[3];
            newTable.Cell(12, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 2; i < 16; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 1];
            }
            newTable.Cell(1, 3).Range.Text = Item[6];
            newTable.Cell(1, 4).Range.Text = Item[7];
            newTable.Cell(1, 5).Range.Text = Item[8];

            string[] mingji_yaosu = orcl_W.getMianjiOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
            xiaojichangdu = orcl_W.xiaoji_yaosu();

            for (int i = 0; i < 14; i++)
            {
                newTable.Cell(i + 2, 3).Range.Text = mingji_yaosu[i];
            }

            newTable.Cell(2, 4).Range.Text = xiaojichangdu[0];
            newTable.Cell(6, 4).Range.Text = xiaojichangdu[1];
            newTable.Cell(11, 4).Range.Text = xiaojichangdu[2];
            newTable.Cell(12, 4).Range.Text = xiaojichangdu[3];

            Double zongji = 0.0;
            for (int i = 0; i < 4; i++)
            {
                zongji += Convert.ToDouble(xiaojichangdu[i]);
            }
            string hejimian = Convert.ToString(zongji);
            newTable.Cell(2, 5).Range.Text = hejimian;

            return;
        }

        public void WriteToWord_ztfx_zbfg()
        {
            OpenWordFile(fileName);
            CreateTable(16, 10);
            newTable.Cell(1, 3).Merge(newTable.Cell(1, 4));
            newTable.Cell(1, 4).Merge(newTable.Cell(1, 5));
            newTable.Cell(1, 5).Merge(newTable.Cell(1, 6));
            newTable.Cell(1, 6).Merge(newTable.Cell(1, 7));
           // newTable.Cell(1, 7).Merge(newTable.Cell(1, 8));

            newTable.Cell(3, 1).Merge(newTable.Cell(6, 1));
           // newTable.Cell(3, 11).Merge(newTable.Cell(6, 11));

            newTable.Cell(7, 1).Merge(newTable.Cell(11, 1));
           // newTable.Cell(7, 11).Merge(newTable.Cell(11, 11));

            newTable.Cell(13, 1).Merge(newTable.Cell(16, 1));
          //  newTable.Cell(13, 11).Merge(newTable.Cell(16, 11));

          //  newTable.Cell(3, 12).Merge(newTable.Cell(16,12));

            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(3, 1).Range.Text = Column1[1];
            newTable.Cell(7, 1).Range.Text = Column1[2];
            newTable.Cell(12, 1).Range.Text = Column1[3];
            newTable.Cell(13, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 3; i < 17; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 2];
            }
            for (int i = 3; i < 7;i++ )
            {
                 newTable.Cell(1,i).Range.Text = firstRow[i-2];
            }
          //  newTable.Cell(1, 7).Range.Text = "小计";

             for (int i = 2; i < 6;i++ )
            {
                newTable.Cell(2, 2 * i-1).Range.Text = "图斑面积";
                newTable.Cell(2, 2 * i).Range.Text = "占比";
            }
            string[] xianmianji = orcl_W.getArea_xian();
            string[,] mianji = new string[14, 4];
            for (int i = 1; i <= 14; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                     mianji[i - 1, j - 1]= orcl_W.liaohe_dbfg_mianji(i, orcl1.time, j);                    
                }
            }
            string[,] zhanbi = new string[14, 4];
            for (int i = 1; i <= 14; i++)
            {
                for (int j = 1; j <= 4; j++)
                {
                    zhanbi[i - 1, j - 1] = Convert.ToString(Math.Round(Convert.ToDouble(mianji[i - 1, j - 1]) / Convert.ToDouble(xianmianji[i - 1]) * 100, 2))+"%";
                }
            }
            
            for (int i = 0; i < 4;i++)
            {
                newTable.Cell(i + 3, 3).Range.Text = mianji[i + 8, 0];
                newTable.Cell(i + 3, 5).Range.Text = mianji[i + 8, 1];
                newTable.Cell(i + 3, 7).Range.Text = mianji[i + 8, 2];
                newTable.Cell(i + 3, 9).Range.Text = mianji[i + 8, 3];
                                                           
                newTable.Cell(i + 3, 4).Range.Text = zhanbi[i + 8, 0];
                newTable.Cell(i + 3, 6).Range.Text = zhanbi[i + 8, 1];
                newTable.Cell(i + 3, 8).Range.Text = zhanbi[i + 8, 2];
                newTable.Cell(i + 3, 10).Range.Text = zhanbi[i + 8, 3];
            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 7, 3).Range.Text = mianji[i, 0];
                newTable.Cell(i + 7, 5).Range.Text = mianji[i , 1];
                newTable.Cell(i + 7, 7).Range.Text = mianji[i , 2];
                newTable.Cell(i + 7, 9).Range.Text = mianji[i , 3];
                                 
                newTable.Cell(i + 7, 4).Range.Text = zhanbi[i , 0];
                newTable.Cell(i + 7, 6).Range.Text = zhanbi[i , 1];
                newTable.Cell(i + 7, 8).Range.Text = zhanbi[i , 2];
                newTable.Cell(i + 7, 10).Range.Text = zhanbi[i, 3];
            }

            newTable.Cell(12, 3).Range.Text = mianji[5, 0];
            newTable.Cell(12, 5).Range.Text = mianji[5, 1];
            newTable.Cell(12, 7).Range.Text = mianji[5, 2];
            newTable.Cell(12, 9).Range.Text = mianji[5, 3];
                                                     
            newTable.Cell(12, 4).Range.Text = zhanbi[5, 0];
            newTable.Cell(12, 6).Range.Text = zhanbi[5, 1];
            newTable.Cell(12, 8).Range.Text = zhanbi[5, 2];
            newTable.Cell(12, 10).Range.Text = zhanbi[5, 3];

            //兴隆台区
            newTable.Cell(13, 3).Range.Text = mianji[12, 0];
            newTable.Cell(13, 5).Range.Text = mianji[12, 1];
            newTable.Cell(13, 7).Range.Text = mianji[12, 2];
            newTable.Cell(13, 9).Range.Text = mianji[12, 3];
                                                     
            newTable.Cell(13, 4).Range.Text = zhanbi[12, 0];
            newTable.Cell(13, 6).Range.Text = zhanbi[12, 1];
            newTable.Cell(13, 8).Range.Text = zhanbi[12, 2];
            newTable.Cell(13, 10).Range.Text = zhanbi[12, 3];
            //双台子区
            newTable.Cell(14, 3).Range.Text = mianji[6, 0];
            newTable.Cell(14, 5).Range.Text = mianji[6, 1];
            newTable.Cell(14, 7).Range.Text = mianji[6, 2];
            newTable.Cell(14, 9).Range.Text = mianji[6, 3];
                                                    
            newTable.Cell(14, 4).Range.Text = zhanbi[6, 0];
            newTable.Cell(14, 6).Range.Text = zhanbi[6, 1];
            newTable.Cell(14, 8).Range.Text = zhanbi[6, 2];
            newTable.Cell(14, 10).Range.Text = zhanbi[6, 3];
            //盘山县
            newTable.Cell(15, 3).Range.Text = mianji[13, 0];
            newTable.Cell(15, 5).Range.Text = mianji[13, 1];
            newTable.Cell(15, 7).Range.Text = mianji[13, 2];
            newTable.Cell(15, 9).Range.Text = mianji[13, 3];
                                                     
            newTable.Cell(15, 4).Range.Text = zhanbi[13, 0];
            newTable.Cell(15, 6).Range.Text = zhanbi[13, 1];
            newTable.Cell(15, 8).Range.Text = zhanbi[13, 2];
            newTable.Cell(15, 10).Range.Text = zhanbi[13, 3];
            //大洼县

            newTable.Cell(16, 3).Range.Text = mianji[7, 0];
            newTable.Cell(16, 5).Range.Text = mianji[7, 1];
            newTable.Cell(16, 7).Range.Text = mianji[7, 2];
            newTable.Cell(16, 9).Range.Text = mianji[7, 3];
                                                     
            newTable.Cell(16, 4).Range.Text = zhanbi[7, 0];
            newTable.Cell(16, 6).Range.Text = zhanbi[7, 1];
            newTable.Cell(16, 8).Range.Text = zhanbi[7, 2];
            newTable.Cell(16, 10).Range.Text = zhanbi[7, 3];

        }
        public void WriteToWord_ztfx_stfz()
        {
            OpenWordFile(fileName);
            CreateTable(15, 4);
//             newTable.Cell(1, 1).Merge(newTable.Cell(2, 1));
//             newTable.Cell(1, 2).Merge(newTable.Cell(2, 2));
//             newTable.Cell(1, 5).Merge(newTable.Cell(1, 6));
//             newTable.Cell(1, 3).Merge(newTable.Cell(2, 3));
//             newTable.Cell(1, 4).Merge(newTable.Cell(2, 4));

            newTable.Cell(2, 1).Merge(newTable.Cell(5, 1));
//             newTable.Cell(3, 5).Merge(newTable.Cell(6, 5));
//             newTable.Cell(3, 6).Merge(newTable.Cell(6, 6));

            newTable.Cell(6, 1).Merge(newTable.Cell(10, 1));
//             newTable.Cell(7, 5).Merge(newTable.Cell(11, 5));
//             newTable.Cell(7, 6).Merge(newTable.Cell(11, 6));

            newTable.Cell(12, 1).Merge(newTable.Cell(15, 1));
//             newTable.Cell(13, 5).Merge(newTable.Cell(16, 5));
//             newTable.Cell(13, 6).Merge(newTable.Cell(16, 6));

            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(2, 1).Range.Text = Column1[1];
            newTable.Cell(6, 1).Range.Text = Column1[2];
            newTable.Cell(11, 1).Range.Text = Column1[3];
            newTable.Cell(12, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 2; i < 16; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 1];
            }
            newTable.Cell(1, 3).Range.Text = "面积";
            newTable.Cell(1, 4).Range.Text = "占比";

//             newTable.Cell(2, 5).Range.Text = "面积";
//             newTable.Cell(2, 6).Range.Text = "占比";
//             newTable.Cell(1, 5).Range.Text = "小计";
//      
            string[] shuiti_mianji = new string[14];
            for (int i = 1; i <= 14; i++)
            {
               shuiti_mianji[i-1] = orcl_W.liaohe_dbfg_mianji(i, orcl1.time, 10);                
            }
            string[] xian_mianji = orcl_W.getArea_xian();
            string[] zhanbi = new string[14];
            for (int i = 0; i < 14;i++ )
            {
                zhanbi[i] = Convert.ToString(Math.Round(Convert.ToDouble(shuiti_mianji[i]) / Convert.ToDouble(xian_mianji[i]) * 100, 2)) + "%";
            }

            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 3).Range.Text = shuiti_mianji[i + 8];
                newTable.Cell(i + 2, 4).Range.Text = zhanbi[i + 8];
            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 6, 3).Range.Text = shuiti_mianji[i];
                newTable.Cell(i + 6, 4).Range.Text = zhanbi[i];
            }
            newTable.Cell(11, 3).Range.Text = shuiti_mianji[5];
            newTable.Cell(11, 4).Range.Text = zhanbi[5];
            //兴隆台区
            newTable.Cell(12, 3).Range.Text = shuiti_mianji[12];         
            newTable.Cell(12, 4).Range.Text = zhanbi[12];
            //双台子区
            newTable.Cell(13, 3).Range.Text = shuiti_mianji[6];         
            newTable.Cell(13, 4).Range.Text = zhanbi[6];
            //盘山县
            newTable.Cell(14, 3).Range.Text = shuiti_mianji[13];   
            newTable.Cell(14, 4).Range.Text = zhanbi[13];
            //大洼县
            newTable.Cell(15, 3).Range.Text = shuiti_mianji[7];        
            newTable.Cell(15, 4).Range.Text = zhanbi[7];

        }
        public void WriteToWord_ztfx_jtwlmd()
        {
            OpenWordFile(fileName);
            CreateTable(15, 5);
            //             newTable.Cell(1, 1).Merge(newTable.Cell(2, 1));
            //             newTable.Cell(1, 2).Merge(newTable.Cell(2, 2));
            //             newTable.Cell(1, 5).Merge(newTable.Cell(1, 6));
            //             newTable.Cell(1, 3).Merge(newTable.Cell(2, 3));
            //             newTable.Cell(1, 4).Merge(newTable.Cell(2, 4));

            newTable.Cell(2, 1).Merge(newTable.Cell(5, 1));
            //             newTable.Cell(3, 5).Merge(newTable.Cell(6, 5));
            //             newTable.Cell(3, 6).Merge(newTable.Cell(6, 6));

            newTable.Cell(6, 1).Merge(newTable.Cell(10, 1));
            //             newTable.Cell(7, 5).Merge(newTable.Cell(11, 5));
            //             newTable.Cell(7, 6).Merge(newTable.Cell(11, 6));

            newTable.Cell(12, 1).Merge(newTable.Cell(15, 1));
            //             newTable.Cell(13, 5).Merge(newTable.Cell(16, 5));
            //             newTable.Cell(13, 6).Merge(newTable.Cell(16, 6));

            newTable.Cell(1, 1).Range.Text = Column1[0];
            newTable.Cell(2, 1).Range.Text = Column1[1];
            newTable.Cell(6, 1).Range.Text = Column1[2];
            newTable.Cell(11, 1).Range.Text = Column1[3];
            newTable.Cell(12, 1).Range.Text = Column1[4];
            newTable.Cell(1, 2).Range.Text = Column2[0];
            for (int i = 2; i < 16; i++)
            {
                newTable.Cell(i, 2).Range.Text = Column2[i - 1];
            }
            newTable.Cell(1, 3).Range.Text = "公路长度（km）";
            newTable.Cell(1, 4).Range.Text = "县域面积(亩)";
            newTable.Cell(1, 5).Range.Text = "占比";

            string[] teilu_L = new string[14];
            string[] gonglu_L = new string[14];
            string[] chengshidaolulu_L = new string[14];
            string[] xiangcundaolu_L = new string[14];  
      
            teilu_L = orcl_W.getlength_daolu(1);
            gonglu_L = orcl_W.getlength_daolu(2);
            chengshidaolulu_L = orcl_W.getlength_daolu(3);
            xiangcundaolu_L = orcl_W.getlength_daolu(4);


            string[] lu_L = new string[14];
            string[] xian_mianji = orcl_W.getArea_xian();

            for (int i = 0; i < 14; i++)
            {
                lu_L[i] = Convert.ToString(Math.Round(Convert.ToDouble(teilu_L[i]) + Convert.ToDouble(gonglu_L[i]) + Convert.ToDouble(chengshidaolulu_L[i]) + Convert.ToDouble(xiangcundaolu_L[i]),2));
            }
            string[] zhanbi = new string[14];
            for (int i = 0; i < 14; i++)
            {
                zhanbi[i] = Convert.ToString(Math.Round(Convert.ToDouble(lu_L[i]) / Convert.ToDouble(xian_mianji[i]) * 100, 2)) + "%";
            }

            for (int i = 0; i < 4; i++)
            {
                newTable.Cell(i + 2, 3).Range.Text = lu_L[i + 8];
                newTable.Cell(i + 2, 4).Range.Text = xian_mianji[i + 8];
                newTable.Cell(i + 2, 5).Range.Text = zhanbi[i + 8];
            }
            for (int i = 0; i < 5; i++)
            {
                newTable.Cell(i + 6, 3).Range.Text = lu_L[i];
                newTable.Cell(i + 6, 4).Range.Text = xian_mianji[i];
                newTable.Cell(i + 6, 5).Range.Text = zhanbi[i];
            }
            newTable.Cell(11, 3).Range.Text = lu_L[5];
            newTable.Cell(11, 4).Range.Text = xian_mianji[5];
            newTable.Cell(11, 5).Range.Text = zhanbi[5];
            //兴隆台区
            newTable.Cell(12, 3).Range.Text = lu_L[12];
            newTable.Cell(12, 4).Range.Text = xian_mianji[12];
            newTable.Cell(12, 5).Range.Text = zhanbi[12];
            //双台子区
            newTable.Cell(13, 3).Range.Text = lu_L[6];
            newTable.Cell(13, 4).Range.Text = xian_mianji[6];
            newTable.Cell(13, 5).Range.Text = zhanbi[6];
            //盘山县
            newTable.Cell(14, 3).Range.Text = lu_L[13];
            newTable.Cell(14, 4).Range.Text = xian_mianji[13];
            newTable.Cell(14, 5).Range.Text = zhanbi[13];
            //大洼县
            newTable.Cell(15, 3).Range.Text = lu_L[7];
            newTable.Cell(15, 4).Range.Text = xian_mianji[7];
            newTable.Cell(15, 5).Range.Text = zhanbi[7];

        }

    }
}
