﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OracleClient;

namespace orcl
{
    public class orcl1
    {
        public static string yaosu { set; get; }
        public static string time { set; get; }

        private OracleConnection con;
        private OracleCommand cmd;
        private OracleDataAdapter ada;
        private OracleDataReader myDataReader;

        private const string conToDbName = "Data Source=zheng-pc/lhorcl;User ID=sde;PassWord=sde";

        private string command = null;
        private string[] xianqu = { "银州区", "铁岭县", "开原市", "昌图县", "沈北新区", "新民市", "辽中县", "康平县", "法库县", "台安县", "兴隆台区", "双台子区", "盘山县", "大洼县" };

        private void ConnectToDb()
        {
            con = new OracleConnection(conToDbName);
            con.Open();
        }
        public List<string> GetTimeFormOrcl()
        {
            ConnectToDb();
            List<string> time = new List<string>();
            command = "select timesid from lh_times";
            cmd = new OracleCommand(command, con);
            myDataReader = cmd.ExecuteReader();
            while (myDataReader.Read())
            {
                time.Add(myDataReader.GetOracleValue(0).ToString());
            }
            con.Close();
            return time;
        }

        //地表覆盖
        private string GetOrclCommand_mianji(int quyuId, string chooseTime, int typeId)
        {
         
            switch (typeId)
            {
                case 1:
                    command = string.Format("select sum(p.area) from GENGDI_n p where (p.fid = '{0}') and( p.timesid='{1}')", quyuId, chooseTime);
                    break;
                case 2:
                    command = string.Format("select sum(p.area) from YUANDI_n p where (p.fid = '{0}') and( p.timesid='{1}')", quyuId, chooseTime);
                    break;
                case 3:
                    command = string.Format("select sum(p.area) from LINDI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 4:
                    command = string.Format("select sum(p.area) from CAODI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 5:
                    command = string.Format("select sum(p.area) from FANGWUJIANZHU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 6:
                    command = string.Format("select sum(p.area) from DAOLU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 7:
                    command = string.Format("select sum(p.area) from GOUZHUWU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 8:
                    command = string.Format("select sum(p.area) from DUIJUEDI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 9:
                    command = string.Format("select sum(p.area) from HUANGMO_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 10:
                    command = string.Format("select sum(p.area) from SHUIYU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
            }
            return command;
        }
        public string liaohe_dbfg_mianji(int quyuId, string time,int typeId)
        {
            ConnectToDb();
            string mianji = null;
            command = GetOrclCommand_mianji(quyuId, time, typeId);
            cmd = new OracleCommand(command, con);
            myDataReader = cmd.ExecuteReader();
            while (myDataReader.Read())
            {
                if (myDataReader.GetOracleValue(0).ToString() == "Null")
                {
                    mianji = "0";
                }
                else
                {
                    mianji = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) * 0.0015, 2));
                }               
            }
            con.Close();
            return mianji;
        }
        private string GetOrclCommand_tubanshu(int quyuId, string chooseTime, int typeId)
        {

            switch (typeId)
            {
                case 1:
                    command = string.Format("select count(p.area) from GENGDI_n p where (p.fid = '{0}') and( p.timesid='{1}')", quyuId, chooseTime);
                    break;
                case 2:
                    command = string.Format("select count(p.area) from YUANDI_n p where (p.fid = '{0}') and( p.timesid='{1}')", quyuId, chooseTime);
                    break;
                case 3:
                    command = string.Format("select count(p.area) from LINDI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 4:
                    command = string.Format("select count(p.area) from CAODI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 5:
                    command = string.Format("select count(p.area) from FANGWUJIANZHU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 6:
                    command = string.Format("select count(p.area) from DAOLU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 7:
                    command = string.Format("select count(p.area) from GOUZHUWU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 8:
                    command = string.Format("select count(p.area) from DUIJUEDI_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 9:
                    command = string.Format("select count(p.area) from HUANGMO_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
                case 10:
                    command = string.Format("select count(p.area) from SHUIYU_n p where (p.fid = '{0}') and( p.timesid='{1}') ", quyuId, chooseTime);
                    break;
            }
            return command;
        }
        public string liaohe_dbfg_tubanshu(int quyuId, string time, int typeId)
        {
            ConnectToDb();
            string tubanshu = null;
            command = GetOrclCommand_tubanshu(quyuId, time, typeId);
            cmd = new OracleCommand(command, con);
            myDataReader = cmd.ExecuteReader();
            while (myDataReader.Read())
            {
                if (myDataReader.GetOracleValue(0).ToString() == "Null")
                {
                    tubanshu = "0";
                }
                else
                {
                    tubanshu = myDataReader.GetOracleValue(0).ToString();
                }
            }
            con.Close();
            return tubanshu;
        }
        
        //国情要素

        //道路
        private string getCommand_daolu_changdu(int daoluTye, int fid, int nianfen)
        {
            switch (daoluTye)
            {
                case 1:
                    command = string.Format("select sum(t.length) from lrrl_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 2:
                    command = string.Format("select sum(t.length) from LRDL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 3:
                    command = string.Format("select sum(t.length) from LCTL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 4:
                    command = string.Format("select sum(t.length) from LVLL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;

            }
            return command;
        }
        private string getCommand_daolu_geshu(int daoluTye, int fid, int nianfen)
        {
            switch (daoluTye)
            {
                case 1:
                    command = string.Format("select count(t.objectid) from lrrl_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 2:
                    command = string.Format("select count(t.objectid) from LRDL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 3:
                    command = string.Format("select count(t.objectid) from LCTL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;
                case 4:
                    command = string.Format("select count(t.objectid) from LVLL_n t where t.fid={0} and t.timesid={1}", fid, nianfen);
                    break;

            }
            return command;
        }
        public string[] getcount_daolu(int daolutype)
        {
            ConnectToDb();
            string[] daolu_count = new string[14];
            for (int i = 1; i < 15; i++)
            {
                command = getCommand_daolu_geshu(daolutype, i, Convert.ToInt32(orcl1.time));
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        daolu_count[i - 1] = "0";
                    }
                    else
                    {
                        daolu_count[i - 1] = myDataReader.GetOracleValue(0).ToString();
                    }
                }
            }
            con.Close();
            return daolu_count;
        }
        public string[] getlength_daolu(int daolutype)
        {
            ConnectToDb();
            string[] daolu_length = new string[14];
            for (int i = 1; i < 15; i++)
            {
                command = getCommand_daolu_changdu(daolutype, i, Convert.ToInt32(orcl1.time));
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        daolu_length[i - 1] = "0";
                    }
                    else
                    {
                        //daolu_length[i - 1] = myDataReader.GetOracleValue(0).ToString();
                        daolu_length[i - 1] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) / 1000, 2));
                    }
                }
            }
            con.Close();
            return daolu_length;
        }
        //构筑物
        private string getCommand_gouzhuwu_yaosu(int cc, int nianfen, int fid)
        {
            switch (cc)
            {
                case 0721:
                    command = string.Format("select sum(t.length) from sfcl_n t where t.fid={0} and t.timesid={1} and t.cc=0721", fid, nianfen);
                    break;
                case 0722:
                    command = string.Format("select count(t.objectid) from sfcp_n t where t.fid={0} and t.timesid={1} and t.cc=0722", fid, nianfen);
                    break;
                case 0723:
                    command = string.Format("select count(t.objectid) from sfcp_n t where t.fid={0} and t.timesid={1} and t.cc=0723", fid, nianfen);
                    break;
                case 0732:
                    command = string.Format("select count(t.objectid) from sfcp_n t where t.fid={0} and t.timesid={1} and t.cc=0732", fid, nianfen);
                    break;
                case 0735:
                    command = string.Format("select count(t.objectid) from sfcp_n t where t.fid={0} and t.timesid={1} and t.cc=0735", fid, nianfen);
                    break;
                case 0736:
                    command = string.Format("select count(t.objectid) from sfcp_n t where t.fid={0} and t.timesid={1} and t.cc=0736", fid, nianfen);
                    break;

            }
            return command;
        }
        public string[] getResultof_gouzhuwu(int cc, int nianfen)
        {
            ConnectToDb();
            string[] gouzhuwuofonexian = new string[14];

            for (int i = 1; i < 15; i++)
            {
                command = getCommand_gouzhuwu_yaosu(cc, Convert.ToInt32(orcl1.time), i);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        gouzhuwuofonexian[i - 1] = "0";
                    }
                    else
                    {
                        gouzhuwuofonexian[i - 1] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()), 2));
                    }
                }
            }
            con.Close();
            return gouzhuwuofonexian;
        }
        //水域
        private string getCommand_shuiyu(int cc, int nianfen, int fid, int cOrL)
        {
            if (cOrL == 1)
            {
                switch (cc)
                {
                    case 1011:
                        command = string.Format("select count(t.length) from hydl_n t where t.fid={0} and t.timesid={1} and t.cc=1011", fid, nianfen);
                        break;
                    case 1012:
                        command = string.Format("select count(t.length) from hydl_n t where t.fid={0} and t.timesid={1} and t.cc=1012", fid, nianfen);
                        break;
                    case 1031:
                        command = string.Format("select count(t.length) from hydl_n t where t.fid={0} and t.timesid={1} and t.cc=1031", fid, nianfen);
                        break;
                }
            }

            if (cOrL == 2)
            {
                switch (cc)
                {
                    case 1011:
                        command = string.Format("select sum(t.length) from hydl_n t where t.fid={0} and t.timesid={1} and t.cc=1011", fid, nianfen);
                        break;
                    case 1012:
                        command = string.Format("select sum(t.length) from hydl_n t where t.fid={0} and t.timesid={1} and t.cc=1012", fid, nianfen);
                        break;
                }
            }
            return command;
        }
        public string[] getResult_shuiyu(int cc, int nianfen, int cOrL)
        {
            ConnectToDb();
            string[] shuiyu = new string[14];
            for (int i = 1; i < 15; i++)
            {
                command = getCommand_shuiyu(cc, Convert.ToInt32(orcl1.time), i, cOrL);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        shuiyu[i - 1] = "0";
                    }
                    else
                    {
                        if (cOrL == 1)
                        {
                            shuiyu[i - 1] = myDataReader.GetOracleValue(0).ToString();
                        }
                        else
                            shuiyu[i - 1] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) / 1000, 2));
                    }
                }
            }
            con.Close();
            return shuiyu;
        }

        //地理单元
        private string getCommand_dilidanyuan(int table, string nianfen, string cc, int fid)
        {
            if (table == 1)
            {
                command = string.Format("select count(*) from BOUP7_n t where t.timesid={0} and t.fid={1}", nianfen, fid);
            }
            if (table == 2)
            {
                command = string.Format("select count(*) from BERP6_n t where t.timesid={0} and t.fid={1}", nianfen, fid);
            }
            if (table == 3)
            {
                command = string.Format("select count(*) from BUCP_n t where t.timesid={0} and t.fid={1} and t.cc={2}", nianfen, fid, cc);
            }
            return command;
        }
        public string[] getResult_dilidanyuan(int table, string nianfen, string cc)
        {
            ConnectToDb();
            string[] resault = new string[14];
            for (int i = 1; i <15; i++)
            {
                command = getCommand_dilidanyuan(table, nianfen, cc, i);
                cmd = new OracleCommand(command, con);
                try
                {
                    myDataReader = cmd.ExecuteReader();
                    while (myDataReader.Read())
                    {
                        if (myDataReader.GetOracleValue(0).ToString() == "Null")
                        {
                            resault[i - 1] = "0";
                        }
                        else
                        {
                            resault[i - 1] = myDataReader.GetOracleValue(0).ToString();
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    for (int j = 0; j < 14; j++)
                    {
                        resault[j] = "0";
                    }

                }

            }
            con.Close();
            return resault;
        }

        //专题分析
        private int getFid(string xianqu_name)
        {
            int fid = 0;
            switch (xianqu_name)
            {
                case "银州区":
                    fid = 9;
                    break;
                case "铁岭县":
                    fid = 10;
                    break;
                case "开原市":
                    fid = 12;
                    break;
                case "昌图县":
                    fid = 11;
                    break;
                case "沈北新区":
                    fid = 1;
                    break;
                case "新民市":
                    fid = 5;
                    break;
                case "辽中县":
                    fid = 2;
                    break;
                case "康平县":
                    fid = 3;
                    break;
                case "法库县":
                    fid = 4;
                    break;
                case "台安县":
                    fid = 6;
                    break;
                case "兴隆台区":
                    fid = 13;
                    break;
                case "双台子区":
                    fid = 7;
                    break;
                case "盘山县":
                    fid = 14;
                    break;
                case "大洼县":
                    fid = 8;
                    break;

            }
            return fid;
        }
        private string getYaosuTableName(string yaosu_name)
        {
            string yaosuTableName = null;
            switch (yaosu_name)
            {
                case "围栏":
                    yaosuTableName = "SFCL";
                    break;
                case "管理路":
                    yaosuTableName = "LVLL";
                    break;
                case "采砂场":
                    yaosuTableName = "SFCA";
                    break;
                case "护堤林":
                    yaosuTableName = "FHLA";
                    break;
                case "尾矿库":
                    yaosuTableName = "DHF0819";
                    break;
                case "露天矿":
                    yaosuTableName = "sfca";
                    break;
            }
            return yaosuTableName;
        }
        public string[] getCountOfyaosu(string yaosu_name, string yaosu_nianfen)
        {
            ConnectToDb();

            string[] yaosu_count = new string[14];

            string yaosuTableName = getYaosuTableName(yaosu_name);
            for (int i = 0; i < 14; i++)
            {
                int fid = getFid(xianqu[i]);
                command = string.Format("select count(p.objectid) from " + "{0}" + "_n p where (p.fid = '{1}') and( p.timesid='{2}')",
                                                                yaosuTableName, fid, yaosu_nianfen);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        yaosu_count[i] = "0";
                    }
                    else
                    {
                        yaosu_count[i] = myDataReader.GetOracleValue(0).ToString();
                    }
                }
            }
            myDataReader.Dispose();
            myDataReader.Close();
            con.Dispose();
            con.Close();
            return yaosu_count;

        }
        public string[] getChangduOfyaosu(string yaosu_name, string yaosu_nianfen)
        {
            ConnectToDb();
            string[] changdu = new string[14];
            string yaosuTableName = getYaosuTableName(yaosu_name);
            for (int i = 0; i < 14; i++)
            {
                int fid = getFid(xianqu[i]);


                command = string.Format("select sum(p.length) from " + "{0}" + "_n p where (p.fid = '{1}') and( p.timesid='{2}')",
                                                                yaosuTableName, fid, yaosu_nianfen);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        changdu[i] = "0";
                    }
                    else
                    {
                        changdu[i] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) / 1000, 2));
                    }
                }
            }
            myDataReader.Dispose();
            myDataReader.Close();
            con.Dispose();
            con.Close();
            return changdu;
        }

        public string[] getMianjiOfyaosu(string yaosu_name, string yaosu_nianfen)
        {
            ConnectToDb(); 
            string[] minaji = new string[14];
            string yaosuTableName = getYaosuTableName(yaosu_name);
            for (int i = 0; i < 14; i++)
            {
                int fid = getFid(xianqu[i]);


                command = string.Format("select sum(p.area) from " + "{0}" + "_n p where (p.fid = '{1}') and( p.timesid='{2}') ",
                                                                yaosuTableName, fid, yaosu_nianfen);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                    {
                        minaji[i] = "0";
                    }
                    else
                    {
                        minaji[i] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) * 0.0015, 2));
                    }
                }
            }
            myDataReader.Dispose();
            myDataReader.Close();
            con.Dispose();
            con.Close();
            return minaji;
        }
        public string[] xiaoji_yaosu()
        {
            string[] xj_yaosu = new string[8];
            string[] yaosu = new string[14];
            string[] yaosu1 = new string[14];
            if (orcl.orcl1.yaosu == "围栏" || orcl.orcl1.yaosu == "管理路")
                yaosu = getChangduOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
            if (orcl.orcl1.yaosu == "采砂场")
            {
                yaosu1 = getCountOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
                yaosu = getMianjiOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);

                int linshi_geshu = 0;
                for (int i = 0; i < 4; i++)
                {

                    linshi_geshu += Convert.ToInt32(yaosu1[i]);
                }
                xj_yaosu[4] = Convert.ToString(linshi_geshu);
                linshi_geshu = 0;
                for (int i = 4; i < 9; i++)
                {
                    linshi_geshu += Convert.ToInt32(yaosu1[i]);
                }
                xj_yaosu[5] = Convert.ToString(linshi_geshu);
                linshi_geshu = 0;
                xj_yaosu[6] = Convert.ToString(Math.Round(Convert.ToDouble(yaosu1[9]), 2));
                linshi_geshu = 0;
                for (int i = 10; i < 14; i++)
                {
                    linshi_geshu += Convert.ToInt32(yaosu1[i]);
                }
                xj_yaosu[7] = Convert.ToString(linshi_geshu);
            }
            if (orcl.orcl1.yaosu == "护堤林")
            {
                yaosu = getMianjiOfyaosu(orcl.orcl1.yaosu, orcl.orcl1.time);
            }
            double linshi_changdu = 0.0;
            for (int i = 0; i < 4; i++)
            {

                linshi_changdu += Convert.ToDouble(yaosu[i]);
            }
            xj_yaosu[0] = Convert.ToString(Math.Round(linshi_changdu, 2));
            linshi_changdu = 0.0;
            for (int i = 4; i < 9; i++)
            {
                linshi_changdu += Convert.ToDouble(yaosu[i]);
            }
            xj_yaosu[1] = Convert.ToString(Math.Round(linshi_changdu, 2));
            linshi_changdu = 0.0;
            xj_yaosu[2] = Convert.ToString(Math.Round(Convert.ToDouble(yaosu[9]), 2));
            linshi_changdu = 0.0;
            for (int i = 10; i < 14; i++)
            {
                linshi_changdu += Convert.ToDouble(yaosu[i]);
            }
            xj_yaosu[3] = Convert.ToString(Math.Round(linshi_changdu, 2));



            return xj_yaosu;
        }

        public string[] getArea_shi()
        {
            ConnectToDb();
            string[] xian_mianji = new string[4];
            for (int i = 0; i < 4; i++)
            {
                command = string.Format("select t.area from boua4_n t where t.objectid={0}", i + 1);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                        xian_mianji[i] = "0";
                    else
                    {
                        xian_mianji[i] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) * 0.0015, 2));
                    }
                }
            }
            con.Close();
            return xian_mianji;
        }
        public string[] getArea_xian()
        {
            ConnectToDb();
            string[] xian_mianji = new string[14];
            for (int i = 0; i < 14; i++)
            {
                command = string.Format("select t.area from boua9_n t where t.objectid={0}", i + 1);
                cmd = new OracleCommand(command, con);
                myDataReader = cmd.ExecuteReader();
                while (myDataReader.Read())
                {
                    if (myDataReader.GetOracleValue(0).ToString() == "Null")
                        xian_mianji[i] = "0";
                    else
                    {
                        xian_mianji[i] = Convert.ToString(Math.Round(Convert.ToDouble(myDataReader.GetOracleValue(0).ToString()) * 0.0015, 2));
                    }
                }
            }
            con.Close();
            return xian_mianji;
        }
    }
}
